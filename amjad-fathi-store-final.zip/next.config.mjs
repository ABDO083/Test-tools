/** @type {import('next').NextConfig} */
const nextConfig = {
  typescript: {
    ignoreBuildErrors: true,
  },
  images: {
    unoptimized: true,
  },
  allowedDevOrigins: ['3000-i8xsaucp5uhirkfyzmgsf-4241a9c2.us4.manus.computer'],
}

export default nextConfig
