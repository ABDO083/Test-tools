import { ProductCard } from '@/components/product-card'
import { SectionHeading } from '@/components/section-heading'
import type { Product } from '@/lib/types'

export function RelatedProducts({ products }: { products: Product[] }) {
  if (products.length === 0) return null

  return (
    <section className="mt-10 sm:mt-12">
      <SectionHeading title="منتجات ذات صلة" />
      <div className="mt-4 grid grid-cols-2 gap-3 sm:mt-5 sm:gap-5 lg:grid-cols-4">
        {products.map((product) => (
          <ProductCard key={product.id} product={product} />
        ))}
      </div>
    </section>
  )
}
