import Image from 'next/image'
import Link from 'next/link'
import { cn } from '@/lib/utils'

interface BrandLogoProps {
  className?: string
  variant?: 'default' | 'inverted'
}

export function BrandLogo({ className, variant = 'default' }: BrandLogoProps) {
  const inverted = variant === 'inverted'

  return (
    <Link
      href="/"
      className={cn('flex items-center gap-2.5', className)}
      aria-label="Amjad Fathi Store - الصفحة الرئيسية"
    >
      <Image
        src="/amjad-fathi-logo.png"
        alt="شعار Amjad Fathi Store"
        width={56}
        height={56}
        priority
        className="size-12 rounded-lg object-contain sm:size-14"
      />
      <span className={cn('flex flex-col leading-none', inverted ? 'text-white' : 'text-primary')}>
        <span className="font-display text-lg font-extrabold tracking-wide sm:text-xl">
          Amjad Fathi Store
        </span>
        <span className={cn('mt-1 text-[0.62rem] font-bold', inverted ? 'text-white/70' : 'text-primary/70')}>
          Industrial Tools Store
        </span>
      </span>
    </Link>
  )
}
