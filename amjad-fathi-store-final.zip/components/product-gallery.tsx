'use client'

import * as React from 'react'
import Image from 'next/image'
import { cn } from '@/lib/utils'

export function ProductGallery({ images, alt }: { images: string[]; alt: string }) {
  const gallery = images.length > 0 ? images : ['/placeholder.svg']
  const [active, setActive] = React.useState(0)

  return (
    <div className="flex flex-col gap-4">
      <div className="relative aspect-square overflow-hidden rounded-2xl border border-border bg-white">
        <Image
          src={gallery[active] || '/placeholder.svg'}
          alt={alt}
          fill
          priority
          sizes="(max-width: 1024px) 100vw, 50vw"
          className="object-contain p-6"
        />
      </div>

      {gallery.length > 1 && (
        <div className="flex flex-wrap gap-3">
          {gallery.map((img, i) => (
            <button
              key={i}
              type="button"
              onClick={() => setActive(i)}
              aria-label={`عرض الصورة ${i + 1}`}
              aria-pressed={active === i}
              className={cn(
                'relative size-20 overflow-hidden rounded-xl border bg-white transition-colors',
                active === i ? 'border-accent ring-2 ring-accent/30' : 'border-border hover:border-accent/60',
              )}
            >
              <Image src={img || '/placeholder.svg'} alt="" fill className="object-contain p-2" sizes="80px" />
            </button>
          ))}
        </div>
      )}
    </div>
  )
}
