import Link from 'next/link'
import { ArrowLeft } from 'lucide-react'
import { CategoryIcon } from '@/components/category-icon'
import type { Category } from '@/lib/types'

export function CategoryCard({ category, count }: { category: Category; count?: number }) {
  return (
    <Link
      href={`/categories/${category.slug}`}
      className="group flex flex-col gap-3 rounded-2xl border border-border bg-card p-5 transition-all duration-300 hover:-translate-y-1 hover:border-accent/60 hover:shadow-lg hover:shadow-black/5"
    >
      <div className="flex items-center justify-between">
        <span className="grid size-12 place-items-center rounded-xl bg-secondary text-foreground transition-colors group-hover:bg-accent group-hover:text-accent-foreground">
          <CategoryIcon name={category.icon} />
        </span>
        <ArrowLeft className="size-5 text-muted-foreground transition-all group-hover:-translate-x-1 group-hover:text-accent" />
      </div>
      <div>
        <h3 className="font-bold">{category.name}</h3>
        <p className="mt-1 line-clamp-2 text-sm text-muted-foreground">{category.description}</p>
      </div>
      {typeof count === 'number' && (
        <span className="mt-auto text-xs font-medium text-muted-foreground">
          {count} منتج
        </span>
      )}
    </Link>
  )
}
