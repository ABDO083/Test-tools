'use client'

import * as React from 'react'
import Link from 'next/link'
import { ChevronLeft, ChevronRight, SlidersHorizontal } from 'lucide-react'
import { cn } from '@/lib/utils'
import type { Category } from '@/lib/types'

interface CategoryChipsProps {
  categories: Category[]
  value: string
  onChange: (slug: string) => void
}

export function CategoryChips({ categories, value, onChange }: CategoryChipsProps) {
  const scrollerRef = React.useRef<HTMLDivElement>(null)

  const scrollBy = (direction: 'start' | 'end') => {
    const el = scrollerRef.current
    if (!el) return
    el.scrollBy({ left: direction === 'end' ? -280 : 280, behavior: 'smooth' })
  }

  const options = [{ slug: 'all', name: 'الكل' }, ...categories]

  return (
    <div className="flex items-center gap-2 rounded-2xl border border-orange-200 bg-white p-2 shadow-[0_12px_35px_-22px_rgba(0,0,0,0.35)] sm:gap-3 sm:p-3">
      <div className="hidden items-center gap-2 whitespace-nowrap pe-1 text-sm font-semibold text-slate-700 sm:flex">
        <SlidersHorizontal className="size-4 text-primary" />
        تصفية حسب القسم:
      </div>
      <button
        type="button"
        onClick={() => scrollBy('start')}
        aria-label="تمرير لليمين"
        className="hidden size-9 shrink-0 place-items-center rounded-full border border-orange-200 text-primary hover:border-primary hover:text-primary sm:grid"
      >
        <ChevronRight className="size-4" />
      </button>
      <div ref={scrollerRef} className="no-scrollbar flex flex-1 items-center gap-1.5 overflow-x-auto scroll-smooth sm:gap-2">
        {options.map((opt) => {
          const active = value === opt.slug
          return (
            <Link
              key={opt.slug}
              href={opt.slug === 'all' ? '/products' : `/products?category=${opt.slug}`}
              aria-pressed={active}
              className={cn(
                'whitespace-nowrap rounded-full px-3 py-1.5 text-xs font-medium transition-colors sm:px-4 sm:py-2 sm:text-sm',
                active ? 'bg-primary text-primary-foreground shadow-sm' : 'bg-secondary text-secondary-foreground hover:bg-secondary/70',
              )}
            >
              {opt.name}
            </Link>
          )
        })}
      </div>
      <button
        type="button"
        onClick={() => scrollBy('end')}
        aria-label="تمرير لليسار"
        className="hidden size-9 shrink-0 place-items-center rounded-full border border-orange-200 text-primary hover:border-primary hover:text-primary sm:grid"
      >
        <ChevronLeft className="size-4" />
      </button>
    </div>
  )
}
