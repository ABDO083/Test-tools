'use client'

import * as React from 'react'
import Link from 'next/link'
import { Menu, ShoppingCart, X } from 'lucide-react'
import { BrandLogo } from '@/components/brand-logo'
import { Button } from '@/components/ui/button'
import { useCart } from '@/lib/cart-context'

const navLinks = [
  { href: '/', label: 'الرئيسية' },
  { href: '/products', label: 'المنتجات' },
  { href: '/categories', label: 'التصنيفات' },
]

export function SiteHeader() {
  const { count, openCart } = useCart()
  const [mobileOpen, setMobileOpen] = React.useState(false)

  return (
    <header className="reference-header sticky top-0 z-40 bg-white shadow-sm">
      <div className="mx-auto flex h-16 w-full max-w-7xl items-center justify-between gap-3 px-4 sm:h-[74px] sm:gap-4 sm:px-6 lg:px-8">
        <BrandLogo />

        <nav className="hidden items-center gap-7 text-sm font-bold text-slate-700 md:flex" aria-label="التنقل الرئيسي">
          {navLinks.map((link) => (
            <Link key={link.href} href={link.href} className="transition-colors hover:text-primary">
              {link.label}
            </Link>
          ))}
        </nav>

        <div className="flex items-center gap-2">
          <Button
            variant="outline"
            className="relative gap-2 rounded-full border-transparent bg-white text-primary shadow-sm hover:bg-slate-50"
            onClick={openCart}
            aria-label={`فتح السلة، ${count} منتج`}
          >
            <ShoppingCart className="size-5" />
            <span className="hidden sm:inline">السلة</span>
            {count > 0 && (
              <span className="absolute -right-1 -top-1 grid size-5 place-items-center rounded-full bg-accent text-xs font-bold text-accent-foreground">
                {count}
              </span>
            )}
          </Button>

          <Button
            variant="ghost"
            size="icon"
            className="md:hidden"
            aria-label={mobileOpen ? 'إغلاق القائمة' : 'فتح القائمة'}
            aria-expanded={mobileOpen}
            onClick={() => setMobileOpen((value) => !value)}
          >
            {mobileOpen ? <X className="size-5" /> : <Menu className="size-5" />}
          </Button>
        </div>
      </div>

      {mobileOpen && (
        <nav className="border-t border-slate-100 bg-white md:hidden" aria-label="التنقل للجوال">
          <div className="mx-auto flex w-full max-w-7xl flex-col px-4 py-2 sm:px-6">
            {navLinks.map((link) => (
              <Link key={link.href} href={link.href} onClick={() => setMobileOpen(false)} className="rounded-lg px-3 py-3 text-sm font-bold text-slate-700 hover:bg-slate-50">
                {link.label}
              </Link>
            ))}
          </div>
        </nav>
      )}
    </header>
  )
}
