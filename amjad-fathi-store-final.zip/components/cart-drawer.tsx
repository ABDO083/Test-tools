'use client'

import * as React from 'react'
import Link from 'next/link'
import Image from 'next/image'
import { Minus, Plus, ShoppingCart, Trash2, X } from 'lucide-react'
import { Button, buttonVariants } from '@/components/ui/button'
import { cn } from '@/lib/utils'
import { useCart } from '@/lib/cart-context'
import { STORE_WHATSAPP_HREF } from '@/lib/contact'

export function CartDrawer() {
  const {
    items,
    isOpen,
    count,
    closeCart,
    openCart,
    removeItem,
    adjustQuantity,
    clear,
  } = useCart()

  const handleCheckout = () => {
    const orderLines = items.map(
      (item) => `- ${item.product.name} × ${item.quantity}`,
    )
    const message = [
      'مرحباً، أريد إتمام هذا الطلب:',
      ...orderLines,
    ].join('\n')
    window.open(`${STORE_WHATSAPP_HREF}?text=${encodeURIComponent(message)}`, '_blank', 'noopener,noreferrer')
  }

  React.useEffect(() => {
    if (!isOpen) return
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') closeCart()
    }
    document.addEventListener('keydown', onKey)
    document.body.style.overflow = 'hidden'
    return () => {
      document.removeEventListener('keydown', onKey)
      document.body.style.overflow = ''
    }
  }, [isOpen, closeCart])

  return (
    <>
      {/* Floating cart button — sits opposite the logo (start/left in RTL) */}
      <Button
        onClick={openCart}
        className="fixed bottom-5 left-5 z-30 h-12 gap-2 rounded-full px-5 shadow-lg shadow-black/20"
        aria-label={`فتح سلة الطلبات، ${count} منتج`}
      >
        <ShoppingCart className="size-5" />
        <span className="font-semibold">السلة</span>
        {count > 0 && (
          <span className="grid size-5 place-items-center rounded-full bg-accent text-[0.7rem] font-bold text-accent-foreground">
            {count}
          </span>
        )}
      </Button>

      {/* Overlay */}
      <div
        onClick={closeCart}
        aria-hidden={!isOpen}
        className={`fixed inset-0 z-50 bg-black/50 transition-opacity duration-300 ${
          isOpen ? 'opacity-100' : 'pointer-events-none opacity-0'
        }`}
      />

      {/* Panel — slides in from the start edge (right in RTL) */}
      <aside
        role="dialog"
        aria-modal="true"
        aria-label="سلة الطلبات"
        aria-hidden={!isOpen}
        className={`fixed inset-y-0 end-0 z-50 flex w-full max-w-md flex-col bg-background shadow-2xl transition-transform duration-300 ease-out ${
          isOpen ? 'translate-x-0' : 'translate-x-full rtl:-translate-x-full'
        }`}
      >
        <header className="flex items-center justify-between border-b border-border px-5 py-4">
          <div>
            <h2 className="text-lg font-bold">سلة الطلبات</h2>
            <p className="text-sm text-muted-foreground">{count} منتج في السلة</p>
          </div>
          <Button variant="ghost" size="icon" onClick={closeCart} aria-label="إغلاق السلة">
            <X className="size-5" />
          </Button>
        </header>

        {items.length === 0 ? (
          <div className="flex flex-1 flex-col items-center justify-center gap-3 px-6 text-center">
            <div className="grid size-16 place-items-center rounded-full bg-secondary text-muted-foreground">
              <ShoppingCart className="size-7" />
            </div>
            <p className="text-base font-semibold">السلة فارغة</p>
            <p className="text-sm text-muted-foreground">أضف منتجات لتبدأ طلبك</p>
            <Link href="/products" onClick={closeCart} className={cn(buttonVariants(), 'mt-2')}>
              تصفح المنتجات
            </Link>
          </div>
        ) : (
          <>
            <ul className="flex-1 divide-y divide-border overflow-y-auto px-5">
              {items.map((item) => (
                <li key={item.product.id} className="flex gap-3 py-4">
                  <div className="relative size-20 shrink-0 overflow-hidden rounded-lg border border-border bg-white">
                    <Image
                      src={item.product.images[0] || '/placeholder.svg'}
                      alt={item.product.name}
                      fill
                      className="object-contain p-1.5"
                      sizes="80px"
                    />
                  </div>
                  <div className="flex flex-1 flex-col">
                    <Link
                      href={`/products/${item.product.slug}`}
                      onClick={closeCart}
                      className="line-clamp-2 text-sm font-semibold hover:text-accent"
                    >
                      {item.product.name}
                    </Link>
                    <div className="mt-auto flex items-center justify-between pt-2">
                      <div className="flex items-center rounded-lg border border-border">
                        <button type="button"
                          onClick={() => adjustQuantity(item.product.id, -1)}
                          className="grid size-8 place-items-center text-muted-foreground hover:text-foreground"
                          aria-label="تقليل الكمية"
                        >
                          <Minus className="size-4" />
                        </button>
                        <span className="min-w-8 text-center text-sm font-semibold">
                          {item.quantity}
                        </span>
                        <button type="button"
                          onClick={() => adjustQuantity(item.product.id, 1)}
                          className="grid size-8 place-items-center text-muted-foreground hover:text-foreground"
                          aria-label="زيادة الكمية"
                        >
                          <Plus className="size-4" />
                        </button>
                      </div>
                      <button type="button"
                        onClick={() => removeItem(item.product.id)}
                        className="grid size-8 place-items-center rounded-lg text-muted-foreground hover:bg-destructive/10 hover:text-destructive"
                        aria-label="حذف المنتج"
                      >
                        <Trash2 className="size-4" />
                      </button>
                    </div>
                  </div>
                </li>
              ))}
            </ul>

            <footer className="space-y-3 border-t border-border px-5 py-4">
              <Button className="w-full" size="lg" onClick={handleCheckout}>
                إتمام الطلب
              </Button>
              <button type="button"
                onClick={clear}
                className="w-full text-center text-sm text-muted-foreground hover:text-destructive"
              >
                إفراغ السلة
              </button>
            </footer>
          </>
        )}
      </aside>
    </>
  )
}
