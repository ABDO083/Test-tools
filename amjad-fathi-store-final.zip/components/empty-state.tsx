import type * as React from 'react'
import { PackageSearch } from 'lucide-react'

interface EmptyStateProps {
  title?: string
  description?: string
  icon?: React.ReactNode
  action?: React.ReactNode
}

export function EmptyState({
  title = 'لا توجد منتجات',
  description = 'لم نعثر على منتجات مطابقة. جرّب تعديل البحث أو التصنيف.',
  icon,
  action,
}: EmptyStateProps) {
  return (
    <div className="flex flex-col items-center justify-center gap-4 rounded-2xl border border-dashed border-border bg-card/50 px-6 py-16 text-center">
      <div className="grid size-16 place-items-center rounded-full bg-secondary text-muted-foreground">
        {icon ?? <PackageSearch className="size-8" />}
      </div>
      <div className="space-y-1">
        <h3 className="text-lg font-bold">{title}</h3>
        <p className="mx-auto max-w-sm text-sm text-muted-foreground">{description}</p>
      </div>
      {action}
    </div>
  )
}
