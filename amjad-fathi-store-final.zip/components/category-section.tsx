import { CategoryCard } from '@/components/category-card'
import { SectionHeading } from '@/components/section-heading'
import type { Category } from '@/lib/types'

interface CategorySectionProps {
  categories: Category[]
  counts?: Record<string, number>
}

export function CategorySection({ categories, counts }: CategorySectionProps) {
  return (
    <section className="mx-auto w-full max-w-7xl px-4 py-14 sm:px-6 lg:px-8">
      <SectionHeading
        eyebrow="تسوّق حسب الحاجة"
        title="تصفّح حسب التصنيف"
        description="اعثر على الأداة المناسبة بسرعة من خلال تصنيفاتنا المنظمة."
        href="/categories"
      />
      <div className="mt-8 grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {categories.map((category) => (
          <CategoryCard
            key={category.slug}
            category={category}
            count={counts?.[category.slug]}
          />
        ))}
      </div>
    </section>
  )
}
