'use client'

import * as React from 'react'
import { useRouter } from 'next/navigation'
import { SearchBar } from '@/components/search-bar'

export function HeroSection() {
  const router = useRouter()
  const [term, setTerm] = React.useState('')

  const goSearch = (value: string) => {
    const q = value.trim()
    router.push(q ? `/products?search=${encodeURIComponent(q)}` : '/products')
  }

  return (
    <section className="reference-hero relative overflow-hidden text-white">
      <div className="reference-hero-glow absolute inset-0" aria-hidden="true" />
      <div className="relative mx-auto flex min-h-[270px] w-full max-w-7xl flex-col items-center justify-center px-4 py-10 text-center sm:min-h-[360px] sm:px-6 sm:py-12 lg:px-8">
        <h1 className="font-display text-3xl font-extrabold leading-tight sm:text-5xl lg:text-6xl">
          معدات صناعية بمواصفات
          <br />
          عالمية
        </h1>
        <p className="mt-3 text-sm text-white/85 sm:mt-5 sm:text-xl">
          نضع بين يديك القوة والاعتمادية لإنجاز أصعب المهام
        </p>
        <div className="mt-5 w-full max-w-2xl sm:mt-7">
          <SearchBar
            value={term}
            onChange={setTerm}
            onSubmit={goSearch}
            size="lg"
            placeholder="ابحث عن منتج، أداة، أو معدة..."
            className="reference-hero-search h-14 border-white/30 bg-white/15 text-white shadow-xl backdrop-blur-md focus-within:border-white focus-within:ring-white/30 [&_input]:text-white [&_input]:placeholder:text-white/70 [&_svg]:text-white"
          />
        </div>
      </div>
    </section>
  )
}
