interface PageBannerProps {
  title: string
  description?: string
  eyebrow?: string
}

export function PageBanner({ title, description, eyebrow }: PageBannerProps) {
  return (
    <section className="reference-hero relative overflow-hidden text-white">
      <div className="reference-hero-glow absolute inset-0" aria-hidden="true" />
      <div className="relative mx-auto flex min-h-[150px] w-full max-w-7xl flex-col items-center justify-center px-4 py-8 text-center sm:min-h-[210px] sm:px-6 sm:py-10 lg:px-8">
        {eyebrow && <span className="mb-2 text-sm font-bold text-white/80">{eyebrow}</span>}
        <h1 className="font-display text-3xl font-extrabold leading-tight sm:text-5xl">{title}</h1>
        {description && <p className="mt-3 text-sm text-white/85 sm:text-base">{description}</p>}
      </div>
    </section>
  )
}
