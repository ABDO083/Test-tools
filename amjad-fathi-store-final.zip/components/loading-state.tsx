import { Skeleton } from '@/components/ui/skeleton'

export function ProductCardSkeleton() {
  return (
    <div className="flex flex-col overflow-hidden rounded-2xl border border-border bg-card">
      <Skeleton className="aspect-square w-full rounded-none" />
      <div className="flex flex-col gap-2 p-4">
        <Skeleton className="h-3 w-16" />
        <Skeleton className="h-4 w-full" />
        <Skeleton className="h-4 w-3/4" />
        <Skeleton className="mt-2 h-5 w-24" />
        <div className="mt-3 flex gap-2">
          <Skeleton className="h-10 flex-1" />
          <Skeleton className="size-10" />
        </div>
      </div>
    </div>
  )
}

export function CategoryCardSkeleton() {
  return (
    <div className="flex flex-col gap-3 rounded-2xl border border-border bg-card p-5">
      <Skeleton className="size-12 rounded-xl" />
      <Skeleton className="h-5 w-24" />
      <Skeleton className="h-3 w-full" />
    </div>
  )
}
