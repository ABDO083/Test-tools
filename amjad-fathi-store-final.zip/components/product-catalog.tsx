'use client'

import * as React from 'react'
import { SearchBar } from '@/components/search-bar'
import { CategoryChips } from '@/components/category-chips'
import { SortSelect } from '@/components/sort-select'
import { ProductGrid } from '@/components/product-grid'
import { products as allProducts } from '@/lib/data/products'
import type { Category, Product } from '@/lib/types'
import type { ProductSort } from '@/lib/api'

interface ProductCatalogProps {
  categories: Category[]
  initialProducts?: Product[]
  initialCategory?: string
  initialSearch?: string
  showCategoryFilter?: boolean
  showSearch?: boolean
  showSort?: boolean
}

function filterAndSortProducts(
  source: Product[],
  category: string,
  search: string,
  sort: ProductSort,
) {
  const term = search.trim().toLocaleLowerCase()
  const filtered = source.filter((product) => {
    const matchesCategory =
      category === 'all' || (product.categorySlugs ?? [product.categorySlug]).includes(category)
    const haystack = [product.name, product.excerpt, product.description].join(' ').toLocaleLowerCase()
    return matchesCategory && (!term || haystack.includes(term))
  })

  return [...filtered].sort((a, b) => {
    if (sort === 'name') return a.name.localeCompare(b.name, 'ar')
    return Number(Boolean(b.featured)) - Number(Boolean(a.featured))
  })
}

export function ProductCatalog({
  categories,
  initialProducts,
  initialCategory = 'all',
  initialSearch = '',
  showCategoryFilter = true,
  showSearch = true,
  showSort = true,
}: ProductCatalogProps) {
  const [category, setCategory] = React.useState(initialCategory)
  const [search, setSearch] = React.useState(initialSearch)
  const [sort, setSort] = React.useState<ProductSort>('featured')
  const sourceProducts = initialProducts ?? allProducts

  React.useEffect(() => {
    setCategory(initialCategory)
    setSearch(initialSearch)
  }, [initialCategory, initialSearch])

  const products = React.useMemo(
    () => filterAndSortProducts(sourceProducts, showCategoryFilter ? category : initialCategory, search, sort),
    [category, initialCategory, search, showCategoryFilter, sort, sourceProducts],
  )
  const hasSearch = search.trim().length > 0

  return (
    <div className="space-y-4 sm:space-y-5">
      {showSearch && (
        <SearchBar
          value={search}
          onChange={setSearch}
          size="lg"
          placeholder="ابحث عن منتج، أداة، أو معدة..."
        />
      )}

      {showCategoryFilter && (
        <CategoryChips categories={categories} value={category} onChange={setCategory} />
      )}

      <div className="flex flex-wrap items-center justify-between gap-3">
        <p className="text-sm text-muted-foreground" aria-live="polite">
          {products.length} منتج
          {hasSearch ? ` لنتائج «${search.trim()}»` : ''}
        </p>
        {showSort && <SortSelect value={sort} onChange={setSort} />}
      </div>

      <ProductGrid
        products={products}
        emptyTitle={hasSearch ? 'لا توجد نتائج مطابقة' : 'لا توجد منتجات'}
        emptyDescription={
          hasSearch ? 'جرّب كلمات بحث مختلفة أو اختر تصنيفاً آخر.' : 'لا توجد منتجات في هذا التصنيف حالياً.'
        }
      />
    </div>
  )
}
