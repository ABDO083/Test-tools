import { Mail, MapPin, Phone } from 'lucide-react'
import { BrandLogo } from '@/components/brand-logo'
import { STORE_PHONE_LOCAL, STORE_TEL_HREF, STORE_WHATSAPP_HREF } from '@/lib/contact'

export function SiteFooter() {
  return (
    <footer className="mt-12 border-t border-border/70 bg-primary text-primary-foreground sm:mt-16">
      <div className="mx-auto flex w-full max-w-3xl flex-col items-center px-4 py-10 text-center sm:px-6 sm:py-12">
        <h2 className="text-lg font-bold">معلومات التواصل</h2>
        <ul className="mt-5 grid w-full gap-3 text-sm text-primary-foreground/80 sm:mt-6 sm:gap-4 sm:grid-cols-2">
          <li>
            <a
              href="mailto:emtopsudan@gmail.com"
              className="flex items-center justify-center gap-2.5 transition-colors hover:text-accent"
            >
              <Mail className="size-4 shrink-0" />
              <span dir="ltr">emtopsudan@gmail.com</span>
            </a>
          </li>
          <li>
            <a
              href={STORE_TEL_HREF}
              className="flex items-center justify-center gap-2.5 transition-colors hover:text-accent"
            >
              <Phone className="size-4 shrink-0" />
              <span dir="ltr">{STORE_PHONE_LOCAL}</span>
            </a>
          </li>
          <li>
            <a
              href={STORE_WHATSAPP_HREF}
              target="_blank"
              rel="noreferrer"
              className="flex items-center justify-center gap-2.5 transition-colors hover:text-accent"
            >
              <Phone className="size-4 shrink-0" />
              <span>واتساب</span>
            </a>
          </li>
          <li className="flex items-center justify-center gap-2.5">
            <MapPin className="size-4 shrink-0" />
            <span>الخرطوم - شارع الحرية - المنطقة الصناعية</span>
          </li>
        </ul>
        <BrandLogo variant="inverted" className="mt-7 justify-center sm:mt-9" />
      </div>
    </footer>
  )
}
