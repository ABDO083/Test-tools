'use client'

import * as React from 'react'
import { Check, ShoppingCart } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { useCart } from '@/lib/cart-context'
import type { Product } from '@/lib/types'
import { cn } from '@/lib/utils'

interface AddToCartButtonProps {
  product: Product
  quantity?: number
  className?: string
  size?: React.ComponentProps<typeof Button>['size']
  variant?: React.ComponentProps<typeof Button>['variant']
}

export function AddToCartButton({
  product,
  quantity = 1,
  className,
  size,
  variant = 'default',
}: AddToCartButtonProps) {
  const { addItem } = useCart()
  const [added, setAdded] = React.useState(false)
  const timeout = React.useRef<ReturnType<typeof setTimeout> | null>(null)
  const clickLock = React.useRef(false)
  React.useEffect(() => () => {
    if (timeout.current) clearTimeout(timeout.current)
  }, [])

  const handleClick = () => {
    if (clickLock.current) return
    clickLock.current = true
    addItem(product, quantity)
    setAdded(true)
    if (timeout.current) clearTimeout(timeout.current)
    timeout.current = setTimeout(() => {
      clickLock.current = false
      setAdded(false)
    }, 450)
  }

  return (
    <Button
      type="button"
      onClick={handleClick}
      disabled={added}
      className={cn('gap-2', className)}
      size={size}
      variant={variant}
      aria-label={`إضافة ${product.name} إلى السلة`}
    >
      {added ? <><Check className="size-4" />تمت الإضافة</> : <><ShoppingCart className="size-4" />إضافة للسلة</>}
    </Button>
  )
}
