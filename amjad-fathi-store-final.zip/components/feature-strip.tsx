import { Truck, ShieldCheck, Headset, BadgePercent } from 'lucide-react'

const features = [
  {
    icon: Truck,
    title: 'توصيل سريع',
    description: 'شحن لجميع المناطق خلال أيام قليلة.',
  },
  {
    icon: ShieldCheck,
    title: 'ضمان موثوق',
    description: 'ضمان رسمي على جميع المعدات.',
  },
  {
    icon: Headset,
    title: 'دعم فني',
    description: 'فريق متخصص لمساعدتك في الاختيار.',
  },
  {
    icon: BadgePercent,
    title: 'أسعار تنافسية',
    description: 'أفضل قيمة مقابل الجودة الصناعية.',
  },
]

export function FeatureStrip() {
  return (
    <section className="border-b border-border bg-card">
      <div className="mx-auto grid w-full max-w-7xl grid-cols-2 gap-px overflow-hidden px-4 sm:px-6 lg:grid-cols-4 lg:px-8">
        {features.map((feature) => (
          <div key={feature.title} className="flex items-start gap-3 py-6 pe-4">
            <span className="grid size-11 shrink-0 place-items-center rounded-xl bg-secondary text-accent">
              <feature.icon className="size-5" aria-hidden="true" />
            </span>
            <div>
              <h3 className="text-sm font-bold">{feature.title}</h3>
              <p className="mt-0.5 text-xs leading-relaxed text-muted-foreground">
                {feature.description}
              </p>
            </div>
          </div>
        ))}
      </div>
    </section>
  )
}
