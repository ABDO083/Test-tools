import {
  Zap,
  Flame,
  Wrench,
  Hammer,
  Cog,
  Droplets,
  BatteryCharging,
  Wind,
  Sprout,
  Layers3,
  Boxes,
  Sparkles,
  Package,
  type LucideIcon,
} from 'lucide-react'
import { cn } from '@/lib/utils'

const iconMap: Record<string, LucideIcon> = {
  Zap,
  Flame,
  Wrench,
  Hammer,
  Cog,
  Droplets,
  BatteryCharging,
  Wind,
  Sprout,
  Layers3,
  Boxes,
  Sparkles,
}

export function CategoryIcon({ name, className }: { name: string; className?: string }) {
  const Icon = iconMap[name] ?? Package
  return <Icon className={cn('size-6', className)} aria-hidden="true" />
}
