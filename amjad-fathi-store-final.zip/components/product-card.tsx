import Link from 'next/link'
import Image from 'next/image'
import { AddToCartButton } from '@/components/add-to-cart-button'
import { categories } from '@/lib/data/categories'
import type { Product } from '@/lib/types'
import { cn } from '@/lib/utils'

export function ProductCard({ product }: { product: Product }) {
  const categoryNames = (product.categorySlugs ?? [product.categorySlug])
    .map((slug) => categories.find((category) => category.slug === slug)?.name)
    .filter((name): name is string => Boolean(name))

  return (
    <article className="group flex h-full flex-col overflow-hidden rounded-2xl border border-orange-100 bg-white shadow-[0_10px_30px_-22px_rgba(0,0,0,0.45)] transition-all duration-300 hover:-translate-y-1 hover:border-orange-200 hover:shadow-xl">
      <Link href={`/products/${product.slug}`} className="relative block aspect-square overflow-hidden bg-white">
        <Image
          src={product.images[0] || '/placeholder.svg'}
          alt={product.name}
          fill
          sizes="(max-width: 640px) 50vw, (max-width: 1024px) 33vw, 25vw"
          className="object-contain p-3 transition-transform duration-300 group-hover:scale-105 sm:p-4"
        />
        {product.badge && (
          <span className="absolute end-3 top-3 rounded-full bg-primary px-2.5 py-1 text-[0.65rem] font-bold text-white">
            {product.badge}
          </span>
        )}
      </Link>

      <div className="flex flex-1 flex-col p-3 text-right sm:p-4">
        {categoryNames.length > 0 && (
          <div className="flex flex-wrap gap-1">
            {categoryNames.map((name) => (
              <span key={name} className="text-[0.68rem] font-bold text-muted-foreground">
                {name}
              </span>
            ))}
          </div>
        )}
        <h3 className="mt-1 line-clamp-2 min-h-11 text-base font-bold leading-snug text-slate-800">
          <Link href={`/products/${product.slug}`} className="hover:text-primary">
            {product.name}
          </Link>
        </h3>
        <p className="mt-1 min-h-8 line-clamp-2 text-xs leading-4 text-muted-foreground">{product.excerpt}</p>
        <p className={cn('mt-2 min-h-4 text-xs font-semibold', product.inStock ? 'text-emerald-600' : 'text-destructive')}>
          {product.inStock ? 'متوفر في المخزون' : 'غير متوفر حالياً'}
        </p>
        <div className="mt-auto pt-2 sm:pt-3">
          <AddToCartButton product={product} className="w-full rounded-full bg-primary px-3 text-xs text-white hover:bg-primary/90" />
        </div>
        <Link href={`/products/${product.slug}`} className="mt-2 text-center text-xs font-bold text-primary hover:underline">
          التفاصيل
        </Link>
      </div>
    </article>
  )
}
