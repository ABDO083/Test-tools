'use client'

import * as React from 'react'
import { Search, X } from 'lucide-react'
import { cn } from '@/lib/utils'

interface SearchBarProps {
  value: string
  onChange: (value: string) => void
  onSubmit?: (value: string) => void
  placeholder?: string
  className?: string
  size?: 'default' | 'lg'
  autoFocus?: boolean
}

export function SearchBar({
  value,
  onChange,
  onSubmit,
  placeholder = 'ابحث عن منتج، أداة، أو معدة...',
  className,
  size = 'default',
  autoFocus,
}: SearchBarProps) {
  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter' && !e.nativeEvent.isComposing && e.keyCode !== 229) {
      onSubmit?.(value)
    }
  }

  return (
    <div
      className={cn(
        'flex items-center gap-3 rounded-full border border-border bg-card px-4 shadow-sm transition-colors focus-within:border-accent focus-within:ring-2 focus-within:ring-accent/30',
        size === 'lg' ? 'h-14' : 'h-11',
        className,
      )}
    >
      <Search className="size-5 shrink-0 text-muted-foreground" aria-hidden="true" />
      <input
        type="search"
        inputMode="search"
        value={value}
        autoFocus={autoFocus}
        onChange={(e) => onChange(e.target.value)}
        onKeyDown={handleKeyDown}
        placeholder={placeholder}
        aria-label="بحث"
        className="min-w-0 flex-1 bg-transparent text-sm outline-none placeholder:text-muted-foreground [&::-webkit-search-cancel-button]:hidden"
      />
      {value && (
        <button
          type="button"
          onClick={() => onChange('')}
          aria-label="مسح البحث"
          className="grid size-6 shrink-0 place-items-center rounded-full text-muted-foreground hover:bg-secondary hover:text-foreground"
        >
          <X className="size-4" />
        </button>
      )}
    </div>
  )
}
