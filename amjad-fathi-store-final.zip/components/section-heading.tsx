import Link from 'next/link'
import { ArrowLeft } from 'lucide-react'

interface SectionHeadingProps {
  eyebrow?: string
  title: string
  description?: string
  href?: string
  linkLabel?: string
}

export function SectionHeading({
  eyebrow,
  title,
  description,
  href,
  linkLabel = 'عرض الكل',
}: SectionHeadingProps) {
  return (
    <div className="flex flex-wrap items-end justify-between gap-4">
      <div>
        {eyebrow && (
          <span className="text-sm font-semibold text-accent">{eyebrow}</span>
        )}
        <h2 className="mt-1 text-2xl font-bold tracking-tight sm:text-3xl">{title}</h2>
        {description && (
          <p className="mt-2 max-w-xl text-sm text-muted-foreground sm:text-base">
            {description}
          </p>
        )}
      </div>
      {href && (
        <Link
          href={href}
          className="inline-flex items-center gap-1.5 text-sm font-semibold text-foreground transition-colors hover:text-accent"
        >
          {linkLabel}
          <ArrowLeft className="size-4" />
        </Link>
      )}
    </div>
  )
}
