'use client'

import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import type { ProductSort } from '@/lib/api'

const sortOptions: { value: ProductSort; label: string }[] = [
  { value: 'featured', label: 'المميزة أولاً' },
  { value: 'name', label: 'الاسم (أبجدياً)' },
]

export function SortSelect({
  value,
  onChange,
}: {
  value: ProductSort
  onChange: (value: ProductSort) => void
}) {
  return (
    <Select value={value} onValueChange={(v) => onChange(v as ProductSort)}>
      <SelectTrigger className="w-full min-w-44 sm:w-56" aria-label="ترتيب المنتجات">
        <SelectValue placeholder="ترتيب حسب" />
      </SelectTrigger>
      <SelectContent>
        {sortOptions.map((opt) => (
          <SelectItem key={opt.value} value={opt.value}>
            {opt.label}
          </SelectItem>
        ))}
      </SelectContent>
    </Select>
  )
}
