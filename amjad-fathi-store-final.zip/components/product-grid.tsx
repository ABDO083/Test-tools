import { ProductCard } from '@/components/product-card'
import { ProductCardSkeleton } from '@/components/loading-state'
import { EmptyState } from '@/components/empty-state'
import type { Product } from '@/lib/types'

interface ProductGridProps {
  products: Product[]
  loading?: boolean
  skeletonCount?: number
  emptyTitle?: string
  emptyDescription?: string
}

export function ProductGrid({
  products,
  loading = false,
  skeletonCount = 8,
  emptyTitle,
  emptyDescription,
}: ProductGridProps) {
  if (loading) {
    return (
      <div className="grid grid-cols-2 gap-3 sm:gap-5 lg:grid-cols-3 xl:grid-cols-4">
        {Array.from({ length: skeletonCount }).map((_, i) => (
          <ProductCardSkeleton key={i} />
        ))}
      </div>
    )
  }

  if (products.length === 0) {
    return <EmptyState title={emptyTitle} description={emptyDescription} />
  }

  return (
    <div className="grid grid-cols-2 gap-3 sm:gap-5 lg:grid-cols-3 xl:grid-cols-4">
      {products.map((product) => (
        <ProductCard key={product.id} product={product} />
      ))}
    </div>
  )
}
