'use client'

import * as React from 'react'
import Link from 'next/link'
import { ArrowRight, Minus, Plus, Check, X } from 'lucide-react'
import { Badge } from '@/components/ui/badge'
import { AddToCartButton } from '@/components/add-to-cart-button'
import { ProductGallery } from '@/components/product-gallery'
import { categories } from '@/lib/data/categories'
import type { Product } from '@/lib/types'

export function ProductDetails({ product }: { product: Product }) {
  const categoryNames = (product.categorySlugs ?? [product.categorySlug])
    .map((slug) => categories.find((item) => item.slug === slug))
    .filter((item): item is NonNullable<typeof item> => Boolean(item))
  const [quantity, setQuantity] = React.useState(1)

  return (
    <div>
      <Link
        href="/"
        aria-label="العودة إلى الصفحة الرئيسية"
        className="inline-flex text-sm font-semibold text-muted-foreground transition-colors hover:text-accent"
      >
        ← العودة للرئيسية
      </Link>

      <div className="mt-4 grid gap-6 lg:mt-6 lg:grid-cols-2 lg:gap-12">
        <ProductGallery images={product.images} alt={product.name} />

        <div className="flex flex-col">
          <div className="flex flex-wrap items-center gap-2">
            {categoryNames.map((item) => (
              <Link key={item.slug} href={`/categories/${item.slug}`}>
                <Badge variant="secondary" className="hover:bg-secondary/70">
                  {item.name}
                </Badge>
              </Link>
            ))}
            {product.badge && (
              <Badge className="bg-accent text-accent-foreground hover:bg-accent">
                {product.badge}
              </Badge>
            )}
          </div>

          <h1 className="mt-3 text-2xl font-bold leading-tight sm:text-3xl">{product.name}</h1>

          <div className="mt-3 flex items-center gap-2 text-sm">
            {product.inStock ? (
              <span className="inline-flex items-center gap-1.5 font-medium text-emerald-600">
                <Check className="size-4" /> متوفر في المخزون
              </span>
            ) : (
              <span className="inline-flex items-center gap-1.5 font-medium text-destructive">
                <X className="size-4" /> غير متوفر حالياً
              </span>
            )}
          </div>

          <p className="mt-4 text-sm leading-relaxed text-muted-foreground sm:mt-5 sm:text-base">
            {product.description}
          </p>

          {/* Quantity + actions */}
          <div className="mt-5 flex flex-wrap items-center gap-2.5 sm:mt-6 sm:gap-3">
            <div className="flex items-center rounded-xl border border-border">
              <button type="button"
                onClick={() => setQuantity((q) => Math.max(1, q - 1))}
                className="grid size-11 place-items-center text-muted-foreground hover:text-foreground"
                aria-label="تقليل الكمية"
              >
                <Minus className="size-4" />
              </button>
              <span className="min-w-10 text-center font-semibold">{quantity}</span>
              <button type="button"
                onClick={() => setQuantity((q) => q + 1)}
                className="grid size-11 place-items-center text-muted-foreground hover:text-foreground"
                aria-label="زيادة الكمية"
              >
                <Plus className="size-4" />
              </button>
            </div>
            <AddToCartButton product={product} quantity={quantity} size="lg" className="flex-1 min-w-44" />
          </div>

          {/* Specifications */}
          {product.specifications.length > 0 && (
            <div className="mt-6 sm:mt-8">
              <h2 className="text-lg font-bold">المواصفات</h2>
              <dl className="mt-3 overflow-hidden rounded-xl border border-border">
                {product.specifications.map((spec, i) => (
                  <div
                    key={spec.label}
                    className={`flex items-center justify-between gap-4 px-4 py-3 text-sm ${
                      i % 2 === 0 ? 'bg-secondary/40' : 'bg-card'
                    }`}
                  >
                    <dt className="text-muted-foreground">{spec.label}</dt>
                    <dd className="font-semibold">{spec.value}</dd>
                  </div>
                ))}
              </dl>
            </div>
          )}

          <Link
            href="/products"
            className="mt-6 inline-flex items-center gap-1.5 text-sm font-semibold text-muted-foreground hover:text-accent sm:mt-8"
          >
            <ArrowRight className="size-4" />
            العودة إلى جميع المنتجات
          </Link>
        </div>
      </div>
    </div>
  )
}
