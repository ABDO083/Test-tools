export interface Category {
  slug: string
  name: string
  /** lucide-react icon name used by the CategoryIcon helper */
  icon: string
  description: string
}

export interface ProductSpecification {
  label: string
  value: string
}

export interface Product {
  id: string
  slug: string
  name: string
  categorySlug: string
  categorySlugs?: string[]
  /** short description shown on cards */
  excerpt: string
  /** full description shown on the details page */
  description: string
  badge?: string
  /** first image is treated as the primary/cover image */
  images: string[]
  specifications: ProductSpecification[]
  inStock: boolean
  featured?: boolean
}

export interface CartItem {
  product: Product
  quantity: number
}
