'use client'

import * as React from 'react'
import type { CartItem, Product } from '@/lib/types'

interface CartContextValue {
  items: CartItem[]
  isOpen: boolean
  count: number
  openCart: () => void
  closeCart: () => void
  toggleCart: () => void
  addItem: (product: Product, quantity?: number) => void
  removeItem: (productId: string) => void
  updateQuantity: (productId: string, quantity: number) => void
  adjustQuantity: (productId: string, delta: number) => void
  clear: () => void
}

const CartContext = React.createContext<CartContextValue | null>(null)
const CART_STORAGE_KEY = 'amjad-fathi-cart'

function normalizeQuantity(value: number, fallback = 1) {
  const quantity = Number.isFinite(value) ? Math.floor(value) : fallback
  return Math.max(1, quantity)
}

function normalizeStoredItems(value: unknown): CartItem[] {
  if (!Array.isArray(value)) return []

  return value.flatMap((item) => {
    const candidate = item as Partial<CartItem> | null
    const product = candidate?.product
    if (!product?.id || !product.name || !product.slug) return []

    return [{
      product: {
        ...product,
        images: Array.isArray(product.images) ? product.images.filter((image): image is string => typeof image === 'string') : [],
        specifications: Array.isArray(product.specifications) ? product.specifications : [],
        categorySlugs: Array.isArray(product.categorySlugs) ? product.categorySlugs : [product.categorySlug].filter(Boolean),
        excerpt: typeof product.excerpt === 'string' ? product.excerpt : '',
        description: typeof product.description === 'string' ? product.description : '',
        inStock: product.inStock !== false,
      },
      quantity: normalizeQuantity(Number(candidate?.quantity)),
    }]
  })
}

export function CartProvider({ children }: { children: React.ReactNode }) {
  const [items, setItems] = React.useState<CartItem[]>([])
  const [isOpen, setIsOpen] = React.useState(false)
  const [storageReady, setStorageReady] = React.useState(false)

  React.useEffect(() => {
    try {
      const saved = window.localStorage.getItem(CART_STORAGE_KEY)
      if (saved) setItems(normalizeStoredItems(JSON.parse(saved)))
    } catch {
      window.localStorage.removeItem(CART_STORAGE_KEY)
    } finally {
      setStorageReady(true)
    }
  }, [])

  React.useEffect(() => {
    if (!storageReady) return
    try {
      window.localStorage.setItem(CART_STORAGE_KEY, JSON.stringify(items))
    } catch {
      // Storage failures must not break the interactive cart.
    }
  }, [items, storageReady])

  const addItem = React.useCallback((product: Product, quantity = 1) => {
    const amount = normalizeQuantity(Number(quantity))
    setItems((prev) => {
      const existing = prev.find((i) => i.product.id === product.id)
      if (existing) {
        return prev.map((i) =>
          i.product.id === product.id ? { ...i, quantity: normalizeQuantity(i.quantity) + amount } : i,
        )
      }
      return [...prev, { product, quantity: amount }]
    })
  }, [])

  const removeItem = React.useCallback((productId: string) => {
    setItems((prev) => prev.filter((i) => i.product.id !== productId))
  }, [])

  const updateQuantity = React.useCallback((productId: string, quantity: number) => {
    const nextQuantity = Number(quantity)
    setItems((prev) =>
      !Number.isFinite(nextQuantity) || nextQuantity <= 0
        ? prev.filter((i) => i.product.id !== productId)
        : prev.map((i) => (i.product.id === productId ? { ...i, quantity: normalizeQuantity(nextQuantity) } : i)),
    )
  }, [])

  const adjustQuantity = React.useCallback((productId: string, delta: number) => {
    if (!Number.isFinite(delta) || delta === 0) return
    setItems((prev) => prev.flatMap((item) => {
      if (item.product.id !== productId) return [item]
      const nextQuantity = normalizeQuantity(Number(item.quantity)) + Math.trunc(delta)
      return nextQuantity <= 0 ? [] : [{ ...item, quantity: nextQuantity }]
    }))
  }, [])

  const clear = React.useCallback(() => setItems([]), [])
  const openCart = React.useCallback(() => setIsOpen(true), [])
  const closeCart = React.useCallback(() => setIsOpen(false), [])
  const toggleCart = React.useCallback(() => setIsOpen((v) => !v), [])

  const count = items.reduce((sum, i) => sum + i.quantity, 0)
  const value = React.useMemo(
    () => ({
      items,
      isOpen,
      count,
      openCart,
      closeCart,
      toggleCart,
      addItem,
      removeItem,
      updateQuantity,
      adjustQuantity,
      clear,
    }),
    [items, isOpen, count, openCart, closeCart, toggleCart, addItem, removeItem, updateQuantity, adjustQuantity, clear],
  )

  return <CartContext.Provider value={value}>{children}</CartContext.Provider>
}

export function useCart() {
  const ctx = React.useContext(CartContext)
  if (!ctx) {
    throw new Error('useCart must be used within a CartProvider')
  }
  return ctx
}
