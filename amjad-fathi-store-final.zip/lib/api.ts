import { createClient } from '@supabase/supabase-js'
import { products as localProducts } from '@/lib/data/products'
import { categories as localCategories, getCategoryBySlug } from '@/lib/data/categories'
import type { Category, Product, ProductSpecification } from '@/lib/types'

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL
const supabaseKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY
const supabase = supabaseUrl && supabaseKey ? createClient(supabaseUrl, supabaseKey) : null

export type ProductSort = 'featured' | 'name'

export interface ProductQuery {
  category?: string
  search?: string
  sort?: ProductSort
}

type ProductRow = {
  id: string
  slug: string
  name: string
  excerpt: string
  description: string
  image_path: string | null
  specifications: ProductSpecification[] | null
  in_stock: boolean
  featured: boolean
  product_categories?: Array<{ category?: { slug?: string } | null }>
}

function sortProducts(list: Product[], sort: ProductSort = 'featured'): Product[] {
  const copy = [...list]
  switch (sort) {
    case 'name': return copy.sort((a, b) => a.name.localeCompare(b.name, 'ar'))
    default: return copy.sort((a, b) => Number(Boolean(b.featured)) - Number(Boolean(a.featured)))
  }
}

function mapProduct(row: ProductRow): Product {
  const slugs = (row.product_categories ?? [])
    .map((item) => item.category?.slug)
    .filter((slug): slug is string => Boolean(slug))
  const categorySlugs = slugs.length ? slugs : ['general-equipment']
  return {
    id: row.id,
    slug: row.slug,
    name: row.name,
    categorySlug: categorySlugs[0],
    categorySlugs,
    excerpt: row.excerpt,
    description: row.description,
    images: row.image_path ? [row.image_path] : [],
    specifications: row.specifications ?? [],
    inStock: row.in_stock,
    featured: row.featured,
  }
}

async function getRemoteProducts(): Promise<Product[] | null> {
  if (!supabase) return null
  const { data, error } = await supabase
    .from('products')
    .select('id,slug,name,excerpt,description,image_path,specifications,in_stock,featured,product_categories(category:categories(slug))')
    .limit(500)
  if (error || !data) return null
  return (data as ProductRow[]).map(mapProduct)
}

async function getRemoteCategories(): Promise<Category[] | null> {
  if (!supabase) return null
  const { data, error } = await supabase
    .from('categories')
    .select('slug,name,icon,description')
    .order('sort_order', { ascending: true })
    .limit(100)
  if (error || !data) return null
  return data as Category[]
}

export async function getCategories(): Promise<Category[]> {
  return (await getRemoteCategories()) ?? localCategories
}

export async function getCategory(slug: string): Promise<Category | null> {
  const categories = await getCategories()
  return categories.find((category) => category.slug === slug) ?? getCategoryBySlug(slug) ?? null
}

export async function getProducts(query: ProductQuery = {}): Promise<Product[]> {
  const { category, search, sort } = query
  const all = (await getRemoteProducts()) ?? localProducts
  let list = all
  if (category && category !== 'all') {
    list = list.filter((product) => (product.categorySlugs ?? [product.categorySlug]).includes(category))
  }
  if (search?.trim()) {
    const q = search.trim().toLowerCase()
    list = list.filter((product) =>
      product.name.toLowerCase().includes(q) ||
      product.excerpt.toLowerCase().includes(q) ||
      product.description.toLowerCase().includes(q),
    )
  }
  return sortProducts(list, sort)
}

export async function getProductBySlug(slug: string): Promise<Product | null> {
  const all = (await getRemoteProducts()) ?? localProducts
  return all.find((product) => product.slug === slug) ?? null
}

export async function getFeaturedProducts(limit = 8): Promise<Product[]> {
  const all = (await getRemoteProducts()) ?? localProducts
  return sortProducts(all.filter((product) => product.featured), 'featured').slice(0, limit)
}

export async function getRelatedProducts(product: Product, limit = 4): Promise<Product[]> {
  const all = (await getRemoteProducts()) ?? localProducts
  const productCategories = product.categorySlugs ?? [product.categorySlug]
  const related = all.filter((item) => item.id !== product.id && (item.categorySlugs ?? [item.categorySlug]).some((slug) => productCategories.includes(slug)))
  const relatedIds = new Set(related.map((item) => item.id))
  return [...related, ...all.filter((item) => item.id !== product.id && !relatedIds.has(item.id))].slice(0, limit)
}

export async function getProductCountByCategory(): Promise<Record<string, number>> {
  const all = (await getRemoteProducts()) ?? localProducts
  const counts: Record<string, number> = {}
  for (const product of all) {
    for (const slug of product.categorySlugs ?? [product.categorySlug]) counts[slug] = (counts[slug] ?? 0) + 1
  }
  return counts
}
