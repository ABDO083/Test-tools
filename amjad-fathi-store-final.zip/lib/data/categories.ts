import type { Category } from '@/lib/types'

export const categories: Category[] = [
  {
    slug: 'mechanics',
    name: 'أدوات الميكانيكا',
    icon: 'Cog',
    description: 'أطقم بنص وصواميل ومفكات للورش.',
  },
  {
    slug: 'plumbing',
    name: 'أدوات السباكة',
    icon: 'Wrench',
    description: 'مفاتيح مواسير وأدوات سباكة متينة.',
  },
  {
    slug: 'power-tools',
    name: 'أدوات الكهرباء',
    icon: 'Zap',
    description: 'مثاقب، مناشير وأدوات كهربائية احترافية لكل المهام.',
  },
  {
    slug: 'carpentry',
    name: 'أدوات النجارة',
    icon: 'Hammer',
    description: 'راوترات، مناشير وأدوات تشكيل الخشب.',
  },
  {
    slug: 'metalwork',
    name: 'أدوات الحدادة',
    icon: 'Flame',
    description: 'ماكينات لحام، جلاخات وأدوات قطع المعادن.',
  },
  {
    slug: 'agriculture',
    name: 'الزراعة',
    icon: 'Sprout',
    description: 'معدات وأدوات مساعدة لأعمال الزراعة والعناية بالموقع.',
  },
  {
    slug: 'ceramics',
    name: 'السيراميك',
    icon: 'Layers3',
    description: 'أدوات قص وتركيب وتشطيب السيراميك.',
  },
  {
    slug: 'general-equipment',
    name: 'معدات متنوعة',
    icon: 'Boxes',
    description: 'معدات عملية متعددة الاستخدامات للورش والمواقع.',
  },
  {
    slug: 'water-pumps',
    name: 'مضخات المياه',
    icon: 'Droplets',
    description: 'مضخات مياه غاطسة وسطحية عالية الكفاءة.',
  },
  {
    slug: 'polishing',
    name: 'التلميع والبولش',
    icon: 'Sparkles',
    description: 'أدوات التلميع والصقل للنتائج النهائية الاحترافية.',
  },
  {
    slug: 'cordless',
    name: 'المجموعات اللاسلكية',
    icon: 'BatteryCharging',
    description: 'أدوات لاسلكية تعمل بالبطارية لحرية أكبر.',
  },
  {
    slug: 'compressors',
    name: 'الكمبرسونات وتوابعها',
    icon: 'Wind',
    description: 'كمبروسرات هواء وملحقاتها لكل الاستخدامات.',
  },
]

export function getCategoryBySlug(slug: string): Category | undefined {
  return categories.find((c) => c.slug === slug)
}
