import type { Product } from '@/lib/types'

export const referenceProducts: Product[] = [
  {
    "id": "reference-e74bae9e-8de6-4e25-8352-68cae4a73686",
    "slug": "reference-e74bae9e",
    "name": "بطارية 12v",
    "categorySlug": "general-equipment",
    "categorySlugs": [
      "general-equipment"
    ],
    "excerpt": "بطارية 12v من منتجات Amjad Fathi Store.",
    "description": "بطارية 12v من منتجات Amjad Fathi Store.",
    "images": [
      "/products/reference-optimized/e74bae9e-8de6-4e25-8352-68cae4a73686.webp"
    ],
    "specifications": [],
    "inStock": true,
    "featured": false
  },
  {
    "id": "reference-d73a330c-4074-4732-adef-79a48c4159ec",
    "slug": "reference-d73a330c",
    "name": "طارة حشاشة أشجار 9 بوصة",
    "categorySlug": "agriculture",
    "categorySlugs": [
      "agriculture"
    ],
    "excerpt": "طارة حشاشة أشجار 9 بوصة من منتجات Amjad Fathi Store.",
    "description": "طارة حشاشة أشجار 9 بوصة من منتجات Amjad Fathi Store.",
    "images": [
      "/products/reference-optimized/d73a330c-4074-4732-adef-79a48c4159ec.webp"
    ],
    "specifications": [],
    "inStock": true,
    "featured": false
  },
  {
    "id": "reference-71a4304b-7dd9-4c5d-bc96-f329a554d7e1",
    "slug": "reference-71a4304b",
    "name": "شفاط هواء 12 بوصة",
    "categorySlug": "general-equipment",
    "categorySlugs": [
      "general-equipment"
    ],
    "excerpt": "شفاط هواء 12 بوصة من منتجات Amjad Fathi Store.",
    "description": "شفاط هواء 12 بوصة من منتجات Amjad Fathi Store.",
    "images": [
      "/products/reference-optimized/71a4304b-7dd9-4c5d-bc96-f329a554d7e1.webp"
    ],
    "specifications": [],
    "inStock": true,
    "featured": false
  },
  {
    "id": "reference-8f74f038-e40c-4e09-8896-894d7328b71f",
    "slug": "reference-8f74f038",
    "name": "شفاط هواء 10 بوصة",
    "categorySlug": "general-equipment",
    "categorySlugs": [
      "general-equipment"
    ],
    "excerpt": "شفاط هواء 10 بوصة من منتجات Amjad Fathi Store.",
    "description": "شفاط هواء 10 بوصة من منتجات Amjad Fathi Store.",
    "images": [
      "/products/reference-optimized/8f74f038-e40c-4e09-8896-894d7328b71f.webp"
    ],
    "specifications": [],
    "inStock": true,
    "featured": false
  },
  {
    "id": "reference-d8e7ca20-1f00-4ab5-a6a7-bc94a5933c3c",
    "slug": "reference-d8e7ca20",
    "name": "شفاط هواء 8 بوصة",
    "categorySlug": "general-equipment",
    "categorySlugs": [
      "general-equipment"
    ],
    "excerpt": "شفاط هواء 8 بوصة من منتجات Amjad Fathi Store.",
    "description": "شفاط هواء 8 بوصة من منتجات Amjad Fathi Store.",
    "images": [
      "/products/reference-optimized/d8e7ca20-1f00-4ab5-a6a7-bc94a5933c3c.webp"
    ],
    "specifications": [],
    "inStock": true,
    "featured": false
  },
  {
    "id": "reference-6b18082c-210a-4e44-bd5e-f770ebdaeddb",
    "slug": "reference-6b18082c",
    "name": "دربكين حل ورباط مسامير",
    "categorySlug": "metalwork",
    "categorySlugs": [
      "metalwork",
      "carpentry"
    ],
    "excerpt": "دربكين حل ورباط مسامير من منتجات Amjad Fathi Store.",
    "description": "دربكين حل ورباط مسامير من منتجات Amjad Fathi Store.",
    "images": [
      "/products/reference-optimized/6b18082c-210a-4e44-bd5e-f770ebdaeddb.webp"
    ],
    "specifications": [],
    "inStock": true,
    "featured": false
  },
  {
    "id": "reference-44c8485b-fe0d-4cac-8777-27a8212f89f6",
    "slug": "reference-44c8485b",
    "name": "حجر تلميع شحن",
    "categorySlug": "polishing",
    "categorySlugs": [
      "polishing"
    ],
    "excerpt": "حجر تلميع شحن من منتجات Amjad Fathi Store.",
    "description": "حجر تلميع شحن من منتجات Amjad Fathi Store.",
    "images": [
      "/products/reference-optimized/44c8485b-fe0d-4cac-8777-27a8212f89f6.webp"
    ],
    "specifications": [],
    "inStock": true,
    "featured": false
  },
  {
    "id": "reference-b3cf2b7a-a581-436e-b7e1-037ebd12fd41",
    "slug": "reference-b3cf2b7a",
    "name": "حجر تلميع 1400w",
    "categorySlug": "polishing",
    "categorySlugs": [
      "polishing"
    ],
    "excerpt": "حجر تلميع 1400w من منتجات Amjad Fathi Store.",
    "description": "حجر تلميع 1400w من منتجات Amjad Fathi Store.",
    "images": [
      "/products/reference-optimized/b3cf2b7a-a581-436e-b7e1-037ebd12fd41.webp"
    ],
    "specifications": [],
    "inStock": true,
    "featured": false
  },
  {
    "id": "reference-51530652-6d1e-4758-bb89-15cd2d0640b9",
    "slug": "reference-51530652",
    "name": "هلت 950w",
    "categorySlug": "general-equipment",
    "categorySlugs": [
      "general-equipment",
      "power-tools"
    ],
    "excerpt": "هلت 950w من منتجات Amjad Fathi Store.",
    "description": "هلت 950w من منتجات Amjad Fathi Store.",
    "images": [
      "/products/reference-optimized/51530652-6d1e-4758-bb89-15cd2d0640b9.webp"
    ],
    "specifications": [],
    "inStock": true,
    "featured": false
  },
  {
    "id": "reference-c36b81b5-0cba-4994-a256-bd1d45d2fb62",
    "slug": "reference-c36b81b5",
    "name": "جلاخة 550w",
    "categorySlug": "general-equipment",
    "categorySlugs": [
      "general-equipment"
    ],
    "excerpt": "جلاخة 550w من منتجات Amjad Fathi Store.",
    "description": "جلاخة 550w من منتجات Amjad Fathi Store.",
    "images": [
      "/products/reference-optimized/c36b81b5-0cba-4994-a256-bd1d45d2fb62.webp"
    ],
    "specifications": [],
    "inStock": true,
    "featured": false
  },
  {
    "id": "reference-f00a61db-d49c-4683-b123-2861132b6bb6",
    "slug": "reference-f00a61db",
    "name": "مفك شحن 4v",
    "categorySlug": "mechanics",
    "categorySlugs": [
      "mechanics",
      "carpentry",
      "power-tools",
      "general-equipment"
    ],
    "excerpt": "مفك شحن 4v من منتجات Amjad Fathi Store.",
    "description": "مفك شحن 4v من منتجات Amjad Fathi Store.",
    "images": [
      "/products/reference-optimized/f00a61db-d49c-4683-b123-2861132b6bb6.webp"
    ],
    "specifications": [],
    "inStock": true,
    "featured": false
  },
  {
    "id": "reference-200ea8be-7cd7-4314-9d1a-bb8eddc5cadf",
    "slug": "reference-200ea8be",
    "name": "طقم دربكين 12v قطعة 148",
    "categorySlug": "mechanics",
    "categorySlugs": [
      "mechanics",
      "power-tools",
      "carpentry",
      "general-equipment"
    ],
    "excerpt": "طقم دربكين 12v قطعة 148 من منتجات Amjad Fathi Store.",
    "description": "طقم دربكين 12v قطعة 148 من منتجات Amjad Fathi Store.",
    "images": [
      "/products/reference-optimized/200ea8be-7cd7-4314-9d1a-bb8eddc5cadf.webp"
    ],
    "specifications": [],
    "inStock": true,
    "featured": false
  },
  {
    "id": "reference-9b270e4c-06c5-4d87-8319-3dfa3150c712",
    "slug": "reference-9b270e4c",
    "name": "زردية 7 بوصة",
    "categorySlug": "mechanics",
    "categorySlugs": [
      "mechanics",
      "power-tools"
    ],
    "excerpt": "زردية 7 بوصة من منتجات Amjad Fathi Store.",
    "description": "زردية 7 بوصة من منتجات Amjad Fathi Store.",
    "images": [
      "/products/reference-optimized/9b270e4c-06c5-4d87-8319-3dfa3150c712.webp"
    ],
    "specifications": [],
    "inStock": true,
    "featured": false
  },
  {
    "id": "reference-50c509b8-863d-40cf-b9a4-b7304e135509",
    "slug": "reference-50c509b8",
    "name": "هزاز وقباض سيراميك شحن",
    "categorySlug": "ceramics",
    "categorySlugs": [
      "ceramics"
    ],
    "excerpt": "هزاز وقباض سيراميك شحن من منتجات Amjad Fathi Store.",
    "description": "هزاز وقباض سيراميك شحن من منتجات Amjad Fathi Store.",
    "images": [
      "/products/reference-optimized/50c509b8-863d-40cf-b9a4-b7304e135509.webp"
    ],
    "specifications": [],
    "inStock": true,
    "featured": false
  },
  {
    "id": "reference-d6abf080-56f1-4962-a2ee-93f12232260e",
    "slug": "reference-d6abf080",
    "name": "قاطع سيراميك 800 ملم",
    "categorySlug": "ceramics",
    "categorySlugs": [
      "ceramics"
    ],
    "excerpt": "قاطع سيراميك 800 ملم من منتجات Amjad Fathi Store.",
    "description": "قاطع سيراميك 800 ملم من منتجات Amjad Fathi Store.",
    "images": [
      "/products/reference-optimized/d6abf080-56f1-4962-a2ee-93f12232260e.webp"
    ],
    "specifications": [],
    "inStock": true,
    "featured": false
  },
  {
    "id": "reference-74871a25-02e1-439b-bec5-885813d1ea83",
    "slug": "reference-74871a25",
    "name": "زردية برشام",
    "categorySlug": "general-equipment",
    "categorySlugs": [
      "general-equipment"
    ],
    "excerpt": "زردية برشام من منتجات Amjad Fathi Store.",
    "description": "زردية برشام من منتجات Amjad Fathi Store.",
    "images": [
      "/products/reference-optimized/74871a25-02e1-439b-bec5-885813d1ea83.webp"
    ],
    "specifications": [],
    "inStock": true,
    "featured": false
  },
  {
    "id": "reference-53557e47-c94f-48a2-b79d-26325cf86445",
    "slug": "reference-53557e47",
    "name": "طقم مفكات 6 قطع",
    "categorySlug": "mechanics",
    "categorySlugs": [
      "mechanics",
      "carpentry",
      "power-tools"
    ],
    "excerpt": "طقم مفكات 6 قطع من منتجات Amjad Fathi Store.",
    "description": "طقم مفكات 6 قطع من منتجات Amjad Fathi Store.",
    "images": [
      "/products/reference-optimized/53557e47-c94f-48a2-b79d-26325cf86445.webp"
    ],
    "specifications": [],
    "inStock": true,
    "featured": false
  },
  {
    "id": "reference-1f3896ba-dc5a-4379-bda9-3838eec126d6",
    "slug": "reference-1f3896ba",
    "name": "مفك قياس تيار",
    "categorySlug": "power-tools",
    "categorySlugs": [
      "power-tools"
    ],
    "excerpt": "مفك قياس تيار من منتجات Amjad Fathi Store.",
    "description": "مفك قياس تيار من منتجات Amjad Fathi Store.",
    "images": [
      "/products/reference-optimized/1f3896ba-dc5a-4379-bda9-3838eec126d6.webp"
    ],
    "specifications": [],
    "inStock": true,
    "featured": false
  },
  {
    "id": "reference-5b517826-38bc-457c-91d2-e0e8441dfd1d",
    "slug": "reference-5b517826",
    "name": "بطارية 16v",
    "categorySlug": "general-equipment",
    "categorySlugs": [
      "general-equipment"
    ],
    "excerpt": "بطارية 16v من منتجات Amjad Fathi Store.",
    "description": "بطارية 16v من منتجات Amjad Fathi Store.",
    "images": [
      "/products/reference-optimized/5b517826-38bc-457c-91d2-e0e8441dfd1d.webp"
    ],
    "specifications": [],
    "inStock": true,
    "featured": false
  },
  {
    "id": "reference-b72e88b8-74d1-4b8b-8f04-b534bc4c3da8",
    "slug": "reference-b72e88b8",
    "name": "دربكين 16v 66نيوتن",
    "categorySlug": "power-tools",
    "categorySlugs": [
      "power-tools",
      "carpentry"
    ],
    "excerpt": "دربكين 16v 66نيوتن من منتجات Amjad Fathi Store.",
    "description": "دربكين 16v 66نيوتن من منتجات Amjad Fathi Store.",
    "images": [
      "/products/reference-optimized/b72e88b8-74d1-4b8b-8f04-b534bc4c3da8.webp"
    ],
    "specifications": [],
    "inStock": true,
    "featured": false
  },
  {
    "id": "reference-27b43b4d-cfb7-49e7-adee-18bcbfb8fcfd",
    "slug": "reference-27b43b4d",
    "name": "بطارية 4 امبير",
    "categorySlug": "general-equipment",
    "categorySlugs": [
      "general-equipment"
    ],
    "excerpt": "بطارية 4 امبير من منتجات Amjad Fathi Store.",
    "description": "بطارية 4 امبير من منتجات Amjad Fathi Store.",
    "images": [
      "/products/reference-optimized/27b43b4d-cfb7-49e7-adee-18bcbfb8fcfd.webp"
    ],
    "specifications": [],
    "inStock": true,
    "featured": false
  },
  {
    "id": "reference-4d4ecaa2-b8e0-48bd-8046-fdd54cb931c0",
    "slug": "reference-4d4ecaa2",
    "name": "بطارية 2 امبير",
    "categorySlug": "general-equipment",
    "categorySlugs": [
      "general-equipment"
    ],
    "excerpt": "بطارية 2 امبير من منتجات Amjad Fathi Store.",
    "description": "بطارية 2 امبير من منتجات Amjad Fathi Store.",
    "images": [
      "/products/reference-optimized/4d4ecaa2-b8e0-48bd-8046-fdd54cb931c0.webp"
    ],
    "specifications": [],
    "inStock": true,
    "featured": false
  },
  {
    "id": "reference-7a4b10c2-f993-412e-9ea1-191b82fd3cf0",
    "slug": "reference-7a4b10c2",
    "name": "جاك همر 1700w",
    "categorySlug": "general-equipment",
    "categorySlugs": [
      "general-equipment"
    ],
    "excerpt": "جاك همر 1700w من منتجات Amjad Fathi Store.",
    "description": "جاك همر 1700w من منتجات Amjad Fathi Store.",
    "images": [
      "/products/reference-optimized/7a4b10c2-f993-412e-9ea1-191b82fd3cf0.webp"
    ],
    "specifications": [],
    "inStock": true,
    "featured": false
  },
  {
    "id": "reference-95fbe110-0c22-41b1-9855-822fd66df765",
    "slug": "reference-95fbe110",
    "name": "هوفر تسخين حراري شحن",
    "categorySlug": "general-equipment",
    "categorySlugs": [
      "general-equipment",
      "power-tools"
    ],
    "excerpt": "هوفر تسخين حراري شحن من منتجات Amjad Fathi Store.",
    "description": "هوفر تسخين حراري شحن من منتجات Amjad Fathi Store.",
    "images": [
      "/products/reference-optimized/95fbe110-0c22-41b1-9855-822fd66df765.webp"
    ],
    "specifications": [],
    "inStock": true,
    "featured": false
  },
  {
    "id": "reference-6dd392d3-37c5-4b69-97df-a0e062bb2ded",
    "slug": "reference-6dd392d3",
    "name": "كشاف 4 عيون",
    "categorySlug": "general-equipment",
    "categorySlugs": [
      "general-equipment"
    ],
    "excerpt": "كشاف 4 عيون من منتجات Amjad Fathi Store.",
    "description": "كشاف 4 عيون من منتجات Amjad Fathi Store.",
    "images": [
      "/products/reference-optimized/6dd392d3-37c5-4b69-97df-a0e062bb2ded.webp"
    ],
    "specifications": [],
    "inStock": true,
    "featured": false
  },
  {
    "id": "reference-01a339e2-7699-41c1-9403-56e8ed66abe9",
    "slug": "reference-01a339e2",
    "name": "مفك مقوس 4v",
    "categorySlug": "general-equipment",
    "categorySlugs": [
      "general-equipment"
    ],
    "excerpt": "مفك مقوس 4v من منتجات Amjad Fathi Store.",
    "description": "مفك مقوس 4v من منتجات Amjad Fathi Store.",
    "images": [
      "/products/reference-optimized/01a339e2-7699-41c1-9403-56e8ed66abe9.webp"
    ],
    "specifications": [],
    "inStock": true,
    "featured": false
  },
  {
    "id": "reference-ab5195d5-b7d8-435c-b21a-0e45b8033bc6",
    "slug": "reference-ab5195d5",
    "name": "حجر نار 1200w + دربكين 66 نيوتن + هلت 26 ملم + درل رباط 400 نيوتن + كشاف ضوئي",
    "categorySlug": "cordless",
    "categorySlugs": [
      "cordless"
    ],
    "excerpt": "حجر نار 1200w + دربكين 66 نيوتن + هلت 26 ملم + درل رباط 400 نيوتن + كشاف ضوئي من منتجات Amjad Fathi Store.",
    "description": "حجر نار 1200w + دربكين 66 نيوتن + هلت 26 ملم + درل رباط 400 نيوتن + كشاف ضوئي من منتجات Amjad Fathi Store.",
    "images": [
      "/products/reference-optimized/ab5195d5-b7d8-435c-b21a-0e45b8033bc6.webp"
    ],
    "specifications": [],
    "inStock": true,
    "featured": false
  },
  {
    "id": "reference-b465a4ab-ba80-47c8-8e42-ca1b53d547f4",
    "slug": "reference-b465a4ab",
    "name": "حجر نار 1200w + دربكين 66 نيوتن + هلت 26 ملم",
    "categorySlug": "cordless",
    "categorySlugs": [
      "cordless"
    ],
    "excerpt": "حجر نار 1200w + دربكين 66 نيوتن + هلت 26 ملم من منتجات Amjad Fathi Store.",
    "description": "حجر نار 1200w + دربكين 66 نيوتن + هلت 26 ملم من منتجات Amjad Fathi Store.",
    "images": [
      "/products/reference-optimized/b465a4ab-ba80-47c8-8e42-ca1b53d547f4.webp"
    ],
    "specifications": [],
    "inStock": true,
    "featured": false
  },
  {
    "id": "reference-1823362b-cb0c-44dd-b3d8-509eeb9ed436",
    "slug": "reference-1823362b",
    "name": "حجر نار 1200w + دربكين 66 نيوتن",
    "categorySlug": "cordless",
    "categorySlugs": [
      "cordless"
    ],
    "excerpt": "حجر نار 1200w + دربكين 66 نيوتن من منتجات Amjad Fathi Store.",
    "description": "حجر نار 1200w + دربكين 66 نيوتن من منتجات Amjad Fathi Store.",
    "images": [
      "/products/reference-optimized/1823362b-cb0c-44dd-b3d8-509eeb9ed436.webp"
    ],
    "specifications": [],
    "inStock": true,
    "featured": false
  },
  {
    "id": "reference-23b18543-6ae4-4027-a512-7828629529b5",
    "slug": "reference-23b18543",
    "name": "موتور 1/2 حصان DC 24v LEO",
    "categorySlug": "water-pumps",
    "categorySlugs": [
      "water-pumps"
    ],
    "excerpt": "موتور 1/2 حصان DC 24v LEO من منتجات Amjad Fathi Store.",
    "description": "موتور 1/2 حصان DC 24v LEO من منتجات Amjad Fathi Store.",
    "images": [
      "/products/reference-optimized/23b18543-6ae4-4027-a512-7828629529b5.webp"
    ],
    "specifications": [],
    "inStock": true,
    "featured": false
  },
  {
    "id": "reference-fe1c38c7-2c1c-4d5d-b2a6-80135a5a9de9",
    "slug": "reference-fe1c38c7",
    "name": "موتور مياه 1 حصان تحضير زاتي LEO",
    "categorySlug": "water-pumps",
    "categorySlugs": [
      "water-pumps"
    ],
    "excerpt": "موتور مياه 1 حصان تحضير زاتي LEO من منتجات Amjad Fathi Store.",
    "description": "موتور مياه 1 حصان تحضير زاتي LEO من منتجات Amjad Fathi Store.",
    "images": [
      "/products/reference-optimized/fe1c38c7-2c1c-4d5d-b2a6-80135a5a9de9.webp"
    ],
    "specifications": [],
    "inStock": true,
    "featured": false
  },
  {
    "id": "reference-eb2f37b0-5e8f-4132-acf8-79577d732b22",
    "slug": "reference-eb2f37b0",
    "name": "مغسلة شحن 24.8 Bar",
    "categorySlug": "water-pumps",
    "categorySlugs": [
      "water-pumps"
    ],
    "excerpt": "مغسلة شحن 24.8 Bar من منتجات Amjad Fathi Store.",
    "description": "مغسلة شحن 24.8 Bar من منتجات Amjad Fathi Store.",
    "images": [
      "/products/reference-optimized/eb2f37b0-5e8f-4132-acf8-79577d732b22.webp"
    ],
    "specifications": [],
    "inStock": true,
    "featured": false
  },
  {
    "id": "reference-e2445f99-ed04-41f4-a64d-b690fe7326d4",
    "slug": "reference-e2445f99",
    "name": "مغسلة 1500w/100Bar",
    "categorySlug": "water-pumps",
    "categorySlugs": [
      "water-pumps"
    ],
    "excerpt": "مغسلة 1500w/100Bar من منتجات Amjad Fathi Store.",
    "description": "مغسلة 1500w/100Bar من منتجات Amjad Fathi Store.",
    "images": [
      "/products/reference-optimized/e2445f99-ed04-41f4-a64d-b690fe7326d4.webp"
    ],
    "specifications": [],
    "inStock": true,
    "featured": false
  },
  {
    "id": "reference-10a2aeeb-6225-4074-8a72-ae23dfa7a783",
    "slug": "reference-10a2aeeb",
    "name": "طلمبة رش مبيد 20L ",
    "categorySlug": "agriculture",
    "categorySlugs": [
      "agriculture"
    ],
    "excerpt": "طلمبة رش مبيد 20L  من منتجات Amjad Fathi Store.",
    "description": "طلمبة رش مبيد 20L  من منتجات Amjad Fathi Store.",
    "images": [
      "/products/reference-optimized/10a2aeeb-6225-4074-8a72-ae23dfa7a783.webp"
    ],
    "specifications": [],
    "inStock": true,
    "featured": false
  },
  {
    "id": "reference-463ff29a-e319-4ba7-b345-a4b09ade0d3d",
    "slug": "reference-463ff29a",
    "name": "حشاشة اشجار بنزين 52CC",
    "categorySlug": "agriculture",
    "categorySlugs": [
      "agriculture"
    ],
    "excerpt": "حشاشة اشجار بنزين 52CC من منتجات Amjad Fathi Store.",
    "description": "حشاشة اشجار بنزين 52CC من منتجات Amjad Fathi Store.",
    "images": [
      "/products/reference-optimized/463ff29a-e319-4ba7-b345-a4b09ade0d3d.webp"
    ],
    "specifications": [],
    "inStock": true,
    "featured": false
  },
  {
    "id": "reference-6c93f1e1-8ace-48a1-b8f8-49324beb3069",
    "slug": "reference-6c93f1e1",
    "name": "منشار شجر بنزين 18 بوصة",
    "categorySlug": "agriculture",
    "categorySlugs": [
      "agriculture"
    ],
    "excerpt": "منشار شجر بنزين 18 بوصة من منتجات Amjad Fathi Store.",
    "description": "منشار شجر بنزين 18 بوصة من منتجات Amjad Fathi Store.",
    "images": [
      "/products/reference-optimized/6c93f1e1-8ace-48a1-b8f8-49324beb3069.webp"
    ],
    "specifications": [],
    "inStock": true,
    "featured": false
  },
  {
    "id": "reference-c6ed47f3-f1da-4898-9236-8782ff80a84d",
    "slug": "reference-c6ed47f3",
    "name": "منشار شجر شحن 12 بوصة",
    "categorySlug": "agriculture",
    "categorySlugs": [
      "agriculture"
    ],
    "excerpt": "منشار شجر شحن 12 بوصة من منتجات Amjad Fathi Store.",
    "description": "منشار شجر شحن 12 بوصة من منتجات Amjad Fathi Store.",
    "images": [
      "/products/reference-optimized/c6ed47f3-f1da-4898-9236-8782ff80a84d.webp"
    ],
    "specifications": [],
    "inStock": true,
    "featured": false
  },
  {
    "id": "reference-4db7e3dd-5850-4c5f-b7c6-c70fad868f56",
    "slug": "reference-4db7e3dd",
    "name": "حفار بنزين 52CC",
    "categorySlug": "agriculture",
    "categorySlugs": [
      "agriculture"
    ],
    "excerpt": "حفار بنزين 52CC من منتجات Amjad Fathi Store.",
    "description": "حفار بنزين 52CC من منتجات Amjad Fathi Store.",
    "images": [
      "/products/reference-optimized/4db7e3dd-5850-4c5f-b7c6-c70fad868f56.webp"
    ],
    "specifications": [],
    "inStock": true,
    "featured": false
  },
  {
    "id": "reference-11c261b7-0b7a-4bda-9544-748b2a889b03",
    "slug": "reference-11c261b7",
    "name": "راس كمبرسون 2 بستم",
    "categorySlug": "compressors",
    "categorySlugs": [
      "compressors"
    ],
    "excerpt": "راس كمبرسون 2 بستم من منتجات Amjad Fathi Store.",
    "description": "راس كمبرسون 2 بستم من منتجات Amjad Fathi Store.",
    "images": [
      "/products/reference-optimized/11c261b7-0b7a-4bda-9544-748b2a889b03.webp"
    ],
    "specifications": [],
    "inStock": true,
    "featured": false
  },
  {
    "id": "reference-d98f165a-ddb9-48de-becb-61b3bf7a1f3a",
    "slug": "reference-d98f165a",
    "name": "راس كمبرسون 3 بستم",
    "categorySlug": "compressors",
    "categorySlugs": [
      "compressors"
    ],
    "excerpt": "راس كمبرسون 3 بستم من منتجات Amjad Fathi Store.",
    "description": "راس كمبرسون 3 بستم من منتجات Amjad Fathi Store.",
    "images": [
      "/products/reference-optimized/d98f165a-ddb9-48de-becb-61b3bf7a1f3a.webp"
    ],
    "specifications": [],
    "inStock": true,
    "featured": false
  },
  {
    "id": "reference-7e3d8d3a-dd25-4495-8ecc-4e08f6218f31",
    "slug": "reference-7e3d8d3a",
    "name": "درل هواء 1 بوصة",
    "categorySlug": "compressors",
    "categorySlugs": [
      "compressors",
      "mechanics"
    ],
    "excerpt": "درل هواء 1 بوصة من منتجات Amjad Fathi Store.",
    "description": "درل هواء 1 بوصة من منتجات Amjad Fathi Store.",
    "images": [
      "/products/reference-optimized/7e3d8d3a-dd25-4495-8ecc-4e08f6218f31.webp"
    ],
    "specifications": [],
    "inStock": true,
    "featured": false
  },
  {
    "id": "reference-23f80b75-4bd7-434c-ad65-e3b2e1a842cc",
    "slug": "reference-23f80b75",
    "name": "مسدس غسيل (جاز) RONIX",
    "categorySlug": "compressors",
    "categorySlugs": [
      "compressors"
    ],
    "excerpt": "مسدس غسيل (جاز) RONIX من منتجات Amjad Fathi Store.",
    "description": "مسدس غسيل (جاز) RONIX من منتجات Amjad Fathi Store.",
    "images": [
      "/products/reference-optimized/23f80b75-4bd7-434c-ad65-e3b2e1a842cc.webp"
    ],
    "specifications": [],
    "inStock": true,
    "featured": false
  },
  {
    "id": "reference-8fd6504c-3f90-47f9-8f3a-a25939505df9",
    "slug": "reference-8fd6504c",
    "name": "مسدس هواء بوز WADFOW",
    "categorySlug": "compressors",
    "categorySlugs": [
      "compressors"
    ],
    "excerpt": "مسدس هواء بوز WADFOW من منتجات Amjad Fathi Store.",
    "description": "مسدس هواء بوز WADFOW من منتجات Amjad Fathi Store.",
    "images": [
      "/products/reference-optimized/8fd6504c-3f90-47f9-8f3a-a25939505df9.webp"
    ],
    "specifications": [],
    "inStock": true,
    "featured": false
  },
  {
    "id": "reference-3949ee05-46dd-445f-bf1d-a8445d079a15",
    "slug": "reference-3949ee05",
    "name": "مسدس بوهية",
    "categorySlug": "compressors",
    "categorySlugs": [
      "compressors"
    ],
    "excerpt": "مسدس بوهية من منتجات Amjad Fathi Store.",
    "description": "مسدس بوهية من منتجات Amjad Fathi Store.",
    "images": [
      "/products/reference-optimized/3949ee05-46dd-445f-bf1d-a8445d079a15.webp"
    ],
    "specifications": [],
    "inStock": true,
    "featured": false
  },
  {
    "id": "reference-9197cad8-4d3c-4ba6-ad6e-26a87c349a1e",
    "slug": "reference-9197cad8",
    "name": "كمبرسون 100 لتر",
    "categorySlug": "compressors",
    "categorySlugs": [
      "compressors"
    ],
    "excerpt": "كمبرسون 100 لتر من منتجات Amjad Fathi Store.",
    "description": "كمبرسون 100 لتر من منتجات Amjad Fathi Store.",
    "images": [
      "/products/reference-optimized/9197cad8-4d3c-4ba6-ad6e-26a87c349a1e.webp"
    ],
    "specifications": [],
    "inStock": true,
    "featured": false
  },
  {
    "id": "reference-8b24208d-29fc-4c7c-9b05-107425af6def",
    "slug": "reference-8b24208d",
    "name": "كمبرسون 500 لتر",
    "categorySlug": "compressors",
    "categorySlugs": [
      "compressors"
    ],
    "excerpt": "كمبرسون 500 لتر من منتجات Amjad Fathi Store.",
    "description": "كمبرسون 500 لتر من منتجات Amjad Fathi Store.",
    "images": [
      "/products/reference-optimized/8b24208d-29fc-4c7c-9b05-107425af6def.webp"
    ],
    "specifications": [],
    "inStock": true,
    "featured": false
  },
  {
    "id": "reference-d1bba626-e2bd-49d9-b161-4ad2d423ed45",
    "slug": "reference-d1bba626",
    "name": "كمبرسون 50 لتر كوبلن",
    "categorySlug": "compressors",
    "categorySlugs": [
      "compressors"
    ],
    "excerpt": "كمبرسون 50 لتر كوبلن من منتجات Amjad Fathi Store.",
    "description": "كمبرسون 50 لتر كوبلن من منتجات Amjad Fathi Store.",
    "images": [
      "/products/reference-optimized/d1bba626-e2bd-49d9-b161-4ad2d423ed45.webp"
    ],
    "specifications": [],
    "inStock": true,
    "featured": false
  },
  {
    "id": "reference-93d1fc13-82a0-4e15-aa11-e1f51c4a2f88",
    "slug": "reference-93d1fc13",
    "name": "كمبرسون 50 لتر",
    "categorySlug": "compressors",
    "categorySlugs": [
      "compressors"
    ],
    "excerpt": "كمبرسون 50 لتر من منتجات Amjad Fathi Store.",
    "description": "كمبرسون 50 لتر من منتجات Amjad Fathi Store.",
    "images": [
      "/products/reference-optimized/93d1fc13-82a0-4e15-aa11-e1f51c4a2f88.webp"
    ],
    "specifications": [],
    "inStock": true,
    "featured": false
  },
  {
    "id": "reference-a4caad8e-524f-4447-93d9-e9c574198b10",
    "slug": "reference-a4caad8e",
    "name": "هلت شحن 22 ملم",
    "categorySlug": "power-tools",
    "categorySlugs": [
      "power-tools",
      "general-equipment"
    ],
    "excerpt": "هلت شحن 22 ملم من منتجات Amjad Fathi Store.",
    "description": "هلت شحن 22 ملم من منتجات Amjad Fathi Store.",
    "images": [
      "/products/reference-optimized/a4caad8e-524f-4447-93d9-e9c574198b10.webp"
    ],
    "specifications": [],
    "inStock": true,
    "featured": false
  },
  {
    "id": "reference-7b634826-1701-4514-8a6a-a4f9d46b93a1",
    "slug": "reference-7b634826",
    "name": "زردية مقاس 8 بوصة 1000v",
    "categorySlug": "power-tools",
    "categorySlugs": [
      "power-tools"
    ],
    "excerpt": "زردية مقاس 8 بوصة 1000v من منتجات Amjad Fathi Store.",
    "description": "زردية مقاس 8 بوصة 1000v من منتجات Amjad Fathi Store.",
    "images": [
      "/products/reference-optimized/7b634826-1701-4514-8a6a-a4f9d46b93a1.webp"
    ],
    "specifications": [],
    "inStock": true,
    "featured": false
  },
  {
    "id": "reference-3d66367e-ef67-4006-9c3f-126781cc5126",
    "slug": "reference-3d66367e",
    "name": "شنطة دربكين 12v قطعة 96",
    "categorySlug": "carpentry",
    "categorySlugs": [
      "carpentry",
      "power-tools"
    ],
    "excerpt": "شنطة دربكين 12v قطعة 96 من منتجات Amjad Fathi Store.",
    "description": "شنطة دربكين 12v قطعة 96 من منتجات Amjad Fathi Store.",
    "images": [
      "/products/reference-optimized/3d66367e-ef67-4006-9c3f-126781cc5126.webp"
    ],
    "specifications": [],
    "inStock": true,
    "featured": false
  },
  {
    "id": "reference-a637f324-bdc6-4ed9-81b5-d5d3b496c286",
    "slug": "reference-a637f324",
    "name": "مسدس بوهية شحن",
    "categorySlug": "carpentry",
    "categorySlugs": [
      "carpentry"
    ],
    "excerpt": "مسدس بوهية شحن من منتجات Amjad Fathi Store.",
    "description": "مسدس بوهية شحن من منتجات Amjad Fathi Store.",
    "images": [
      "/products/reference-optimized/a637f324-bdc6-4ed9-81b5-d5d3b496c286.webp"
    ],
    "specifications": [],
    "inStock": true,
    "featured": false
  },
  {
    "id": "reference-c5c5ba4d-0d72-4e43-a5f2-183529682949",
    "slug": "reference-c5c5ba4d",
    "name": "قاطع المونيوم 12 بوصة",
    "categorySlug": "carpentry",
    "categorySlugs": [
      "carpentry"
    ],
    "excerpt": "قاطع المونيوم 12 بوصة من منتجات Amjad Fathi Store.",
    "description": "قاطع المونيوم 12 بوصة من منتجات Amjad Fathi Store.",
    "images": [
      "/products/reference-optimized/c5c5ba4d-0d72-4e43-a5f2-183529682949.webp"
    ],
    "specifications": [],
    "inStock": true,
    "featured": false
  },
  {
    "id": "reference-74b1eeac-073f-4f76-a38a-bfcd2acd09a3",
    "slug": "reference-74b1eeac",
    "name": "دباسة خشب شحن",
    "categorySlug": "carpentry",
    "categorySlugs": [
      "carpentry"
    ],
    "excerpt": "دباسة خشب شحن من منتجات Amjad Fathi Store.",
    "description": "دباسة خشب شحن من منتجات Amjad Fathi Store.",
    "images": [
      "/products/reference-optimized/74b1eeac-073f-4f76-a38a-bfcd2acd09a3.webp"
    ],
    "specifications": [],
    "inStock": true,
    "featured": false
  },
  {
    "id": "reference-472326b8-d0f4-42b4-bead-323af7ceccd1",
    "slug": "reference-472326b8",
    "name": "منشار شجر شحن 16 بوصة",
    "categorySlug": "carpentry",
    "categorySlugs": [
      "carpentry",
      "agriculture"
    ],
    "excerpt": "منشار شجر شحن 16 بوصة من منتجات Amjad Fathi Store.",
    "description": "منشار شجر شحن 16 بوصة من منتجات Amjad Fathi Store.",
    "images": [
      "/products/reference-optimized/472326b8-d0f4-42b4-bead-323af7ceccd1.webp"
    ],
    "specifications": [],
    "inStock": true,
    "featured": false
  },
  {
    "id": "reference-27277d92-7b4c-45a0-8f85-f777f56936c0",
    "slug": "reference-27277d92",
    "name": "مسدس بوهية مباشر 530w",
    "categorySlug": "carpentry",
    "categorySlugs": [
      "carpentry"
    ],
    "excerpt": "مسدس بوهية مباشر 530w من منتجات Amjad Fathi Store.",
    "description": "مسدس بوهية مباشر 530w من منتجات Amjad Fathi Store.",
    "images": [
      "/products/reference-optimized/27277d92-7b4c-45a0-8f85-f777f56936c0.webp"
    ],
    "specifications": [],
    "inStock": true,
    "featured": false
  },
  {
    "id": "reference-aebed8c8-28ef-4013-a612-3926963fedf3",
    "slug": "reference-aebed8c8",
    "name": "طقم الانكي مربع",
    "categorySlug": "mechanics",
    "categorySlugs": [
      "mechanics",
      "power-tools",
      "carpentry"
    ],
    "excerpt": "طقم الانكي مربع من منتجات Amjad Fathi Store.",
    "description": "طقم الانكي مربع من منتجات Amjad Fathi Store.",
    "images": [
      "/products/reference-optimized/aebed8c8-28ef-4013-a612-3926963fedf3.webp"
    ],
    "specifications": [],
    "inStock": true,
    "featured": false
  },
  {
    "id": "reference-d270b274-c51b-45c2-bbe7-4ea7cfca366f",
    "slug": "reference-d270b274",
    "name": "واقي (حامي) ركبة",
    "categorySlug": "mechanics",
    "categorySlugs": [
      "mechanics",
      "plumbing",
      "power-tools",
      "carpentry",
      "metalwork",
      "ceramics"
    ],
    "excerpt": "واقي (حامي) ركبة من منتجات Amjad Fathi Store.",
    "description": "واقي (حامي) ركبة من منتجات Amjad Fathi Store.",
    "images": [
      "/products/reference-optimized/d270b274-c51b-45c2-bbe7-4ea7cfca366f.webp"
    ],
    "specifications": [],
    "inStock": true,
    "featured": false
  },
  {
    "id": "reference-e116b8a8-c3e4-478d-87b2-2dda36b51d4e",
    "slug": "reference-e116b8a8",
    "name": "كلامبيتر 600 AC/DC",
    "categorySlug": "power-tools",
    "categorySlugs": [
      "power-tools"
    ],
    "excerpt": "كلامبيتر 600 AC/DC من منتجات Amjad Fathi Store.",
    "description": "كلامبيتر 600 AC/DC من منتجات Amjad Fathi Store.",
    "images": [
      "/products/reference-optimized/e116b8a8-c3e4-478d-87b2-2dda36b51d4e.webp"
    ],
    "specifications": [],
    "inStock": true,
    "featured": false
  },
  {
    "id": "reference-dd6b2f25-4b19-4752-b26d-5f9ea842b17f",
    "slug": "reference-dd6b2f25",
    "name": "كاوية لحام 800A",
    "categorySlug": "metalwork",
    "categorySlugs": [
      "metalwork"
    ],
    "excerpt": "كاوية لحام 800A من منتجات Amjad Fathi Store.",
    "description": "كاوية لحام 800A من منتجات Amjad Fathi Store.",
    "images": [
      "/products/reference-optimized/dd6b2f25-4b19-4752-b26d-5f9ea842b17f.webp"
    ],
    "specifications": [],
    "inStock": true,
    "featured": false
  },
  {
    "id": "reference-33068fb5-1e24-4254-b0f6-2c5f41f5783a",
    "slug": "reference-33068fb5",
    "name": "كيبل (مشترك) بطارية",
    "categorySlug": "mechanics",
    "categorySlugs": [
      "mechanics"
    ],
    "excerpt": "كيبل (مشترك) بطارية من منتجات Amjad Fathi Store.",
    "description": "كيبل (مشترك) بطارية من منتجات Amjad Fathi Store.",
    "images": [
      "/products/reference-optimized/33068fb5-1e24-4254-b0f6-2c5f41f5783a.webp"
    ],
    "specifications": [],
    "inStock": true,
    "featured": false
  },
  {
    "id": "reference-8ac59bb0-95de-4fb6-aba8-85ea071565cd",
    "slug": "reference-8ac59bb0",
    "name": "طقم زرديات 3 قطع",
    "categorySlug": "mechanics",
    "categorySlugs": [
      "mechanics",
      "power-tools"
    ],
    "excerpt": "طقم زرديات 3 قطع من منتجات Amjad Fathi Store.",
    "description": "طقم زرديات 3 قطع من منتجات Amjad Fathi Store.",
    "images": [
      "/products/reference-optimized/8ac59bb0-95de-4fb6-aba8-85ea071565cd.webp"
    ],
    "specifications": [],
    "inStock": true,
    "featured": false
  },
  {
    "id": "reference-c83acd06-8871-4a00-b0c3-40314ff8822e",
    "slug": "reference-c83acd06",
    "name": "طقم سلاح اركت",
    "categorySlug": "carpentry",
    "categorySlugs": [
      "carpentry"
    ],
    "excerpt": "طقم سلاح اركت من منتجات Amjad Fathi Store.",
    "description": "طقم سلاح اركت من منتجات Amjad Fathi Store.",
    "images": [
      "/products/reference-optimized/c83acd06-8871-4a00-b0c3-40314ff8822e.webp"
    ],
    "specifications": [],
    "inStock": true,
    "featured": false
  },
  {
    "id": "reference-cc430f3f-e0b4-4ba5-b3ae-695396bb178d",
    "slug": "reference-cc430f3f",
    "name": "طقم مدقاب خشابي",
    "categorySlug": "carpentry",
    "categorySlugs": [
      "carpentry"
    ],
    "excerpt": "طقم مدقاب خشابي من منتجات Amjad Fathi Store.",
    "description": "طقم مدقاب خشابي من منتجات Amjad Fathi Store.",
    "images": [
      "/products/reference-optimized/cc430f3f-e0b4-4ba5-b3ae-695396bb178d.webp"
    ],
    "specifications": [],
    "inStock": true,
    "featured": false
  },
  {
    "id": "reference-95fa1264-1828-4640-9222-0d394aea566b",
    "slug": "reference-95fa1264",
    "name": "متر طول 8 متر",
    "categorySlug": "carpentry",
    "categorySlugs": [
      "carpentry",
      "plumbing",
      "metalwork"
    ],
    "excerpt": "متر طول 8 متر من منتجات Amjad Fathi Store.",
    "description": "متر طول 8 متر من منتجات Amjad Fathi Store.",
    "images": [
      "/products/reference-optimized/95fa1264-1828-4640-9222-0d394aea566b.webp"
    ],
    "specifications": [],
    "inStock": true,
    "featured": false
  },
  {
    "id": "reference-e303fd61-fb37-4b6f-8859-5dc67cb6839a",
    "slug": "reference-e303fd61",
    "name": "متر طول 5 متر",
    "categorySlug": "carpentry",
    "categorySlugs": [
      "carpentry",
      "plumbing",
      "metalwork"
    ],
    "excerpt": "متر طول 5 متر من منتجات Amjad Fathi Store.",
    "description": "متر طول 5 متر من منتجات Amjad Fathi Store.",
    "images": [
      "/products/reference-optimized/e303fd61-fb37-4b6f-8859-5dc67cb6839a.webp"
    ],
    "specifications": [],
    "inStock": true,
    "featured": false
  },
  {
    "id": "reference-4033bf88-8d43-42cf-8064-6b045ec6a7ee",
    "slug": "reference-4033bf88",
    "name": "دباسة يدوية",
    "categorySlug": "carpentry",
    "categorySlugs": [
      "carpentry"
    ],
    "excerpt": "دباسة يدوية من منتجات Amjad Fathi Store.",
    "description": "دباسة يدوية من منتجات Amjad Fathi Store.",
    "images": [
      "/products/reference-optimized/4033bf88-8d43-42cf-8064-6b045ec6a7ee.webp"
    ],
    "specifications": [],
    "inStock": true,
    "featured": false
  },
  {
    "id": "reference-50c748f8-cf69-40f4-ba45-884033db02fd",
    "slug": "reference-50c748f8",
    "name": "مفك 8 قطعة سستم",
    "categorySlug": "mechanics",
    "categorySlugs": [
      "mechanics",
      "power-tools",
      "carpentry"
    ],
    "excerpt": "مفك 8 قطعة سستم من منتجات Amjad Fathi Store.",
    "description": "مفك 8 قطعة سستم من منتجات Amjad Fathi Store.",
    "images": [
      "/products/reference-optimized/50c748f8-cf69-40f4-ba45-884033db02fd.webp"
    ],
    "specifications": [],
    "inStock": true,
    "featured": false
  },
  {
    "id": "reference-df72ef5f-2199-4f73-9933-f7331296b309",
    "slug": "reference-df72ef5f",
    "name": "طقم مفك الكترونيات",
    "categorySlug": "power-tools",
    "categorySlugs": [
      "power-tools"
    ],
    "excerpt": "طقم مفك الكترونيات من منتجات Amjad Fathi Store.",
    "description": "طقم مفك الكترونيات من منتجات Amjad Fathi Store.",
    "images": [
      "/products/reference-optimized/df72ef5f-2199-4f73-9933-f7331296b309.webp"
    ],
    "specifications": [],
    "inStock": true,
    "featured": false
  },
  {
    "id": "reference-dac2a3fc-b891-4219-92c1-29a78e54b4b6",
    "slug": "reference-dac2a3fc",
    "name": "مكبس راس سلك BMS",
    "categorySlug": "power-tools",
    "categorySlugs": [
      "power-tools"
    ],
    "excerpt": "مكبس راس سلك BMS من منتجات Amjad Fathi Store.",
    "description": "مكبس راس سلك BMS من منتجات Amjad Fathi Store.",
    "images": [
      "/products/reference-optimized/dac2a3fc-b891-4219-92c1-29a78e54b4b6.webp"
    ],
    "specifications": [],
    "inStock": true,
    "featured": false
  },
  {
    "id": "reference-fb482d72-b9d7-494a-b99e-c8d6981e8c68",
    "slug": "reference-fb482d72",
    "name": "زردية قباض 10 بوصة",
    "categorySlug": "mechanics",
    "categorySlugs": [
      "mechanics"
    ],
    "excerpt": "زردية قباض 10 بوصة من منتجات Amjad Fathi Store.",
    "description": "زردية قباض 10 بوصة من منتجات Amjad Fathi Store.",
    "images": [
      "/products/reference-optimized/fb482d72-b9d7-494a-b99e-c8d6981e8c68.webp"
    ],
    "specifications": [],
    "inStock": true,
    "featured": false
  },
  {
    "id": "reference-91be3f6e-39fb-47fc-a4de-18bd391dfd09",
    "slug": "reference-91be3f6e",
    "name": "فاس 1000 جرام",
    "categorySlug": "carpentry",
    "categorySlugs": [
      "carpentry",
      "agriculture"
    ],
    "excerpt": "فاس 1000 جرام من منتجات Amjad Fathi Store.",
    "description": "فاس 1000 جرام من منتجات Amjad Fathi Store.",
    "images": [
      "/products/reference-optimized/91be3f6e-39fb-47fc-a4de-18bd391dfd09.webp"
    ],
    "specifications": [],
    "inStock": true,
    "featured": false
  },
  {
    "id": "reference-45996dfb-ba73-44be-87c5-38b9f54c7ba1",
    "slug": "reference-45996dfb",
    "name": "طقم مفاتيح خاتم سستم",
    "categorySlug": "mechanics",
    "categorySlugs": [
      "mechanics"
    ],
    "excerpt": "طقم مفاتيح خاتم سستم من منتجات Amjad Fathi Store.",
    "description": "طقم مفاتيح خاتم سستم من منتجات Amjad Fathi Store.",
    "images": [
      "/products/reference-optimized/45996dfb-ba73-44be-87c5-38b9f54c7ba1.webp"
    ],
    "specifications": [],
    "inStock": true,
    "featured": false
  },
  {
    "id": "reference-dedb0463-6c94-4fa7-bdb4-72dfd8d26413",
    "slug": "reference-dedb0463",
    "name": "منشار يدوي 13 بوصة",
    "categorySlug": "carpentry",
    "categorySlugs": [
      "carpentry"
    ],
    "excerpt": "منشار يدوي 13 بوصة من منتجات Amjad Fathi Store.",
    "description": "منشار يدوي 13 بوصة من منتجات Amjad Fathi Store.",
    "images": [
      "/products/reference-optimized/dedb0463-6c94-4fa7-bdb4-72dfd8d26413.webp"
    ],
    "specifications": [],
    "inStock": true,
    "featured": false
  },
  {
    "id": "reference-6dcd7af4-e3c8-4cdf-bd88-13c7ffe35c60",
    "slug": "reference-6dcd7af4",
    "name": "مشحمة يدوية 400 CC",
    "categorySlug": "mechanics",
    "categorySlugs": [
      "mechanics"
    ],
    "excerpt": "مشحمة يدوية 400 CC من منتجات Amjad Fathi Store.",
    "description": "مشحمة يدوية 400 CC من منتجات Amjad Fathi Store.",
    "images": [
      "/products/reference-optimized/6dcd7af4-e3c8-4cdf-bd88-13c7ffe35c60.webp"
    ],
    "specifications": [],
    "inStock": true,
    "featured": false
  },
  {
    "id": "reference-a7b5ae49-a6fe-4133-87d0-be8cbc832dc5",
    "slug": "reference-a7b5ae49",
    "name": "شاكوش 1000 جرام",
    "categorySlug": "mechanics",
    "categorySlugs": [
      "mechanics",
      "carpentry",
      "metalwork"
    ],
    "excerpt": "شاكوش 1000 جرام من منتجات Amjad Fathi Store.",
    "description": "شاكوش 1000 جرام من منتجات Amjad Fathi Store.",
    "images": [
      "/products/reference-optimized/a7b5ae49-a6fe-4133-87d0-be8cbc832dc5.webp"
    ],
    "specifications": [],
    "inStock": true,
    "featured": false
  },
  {
    "id": "reference-5ea029d4-68b1-4ce7-ac64-df17311b6903",
    "slug": "reference-5ea029d4",
    "name": "طقم مفاتيح استندر",
    "categorySlug": "mechanics",
    "categorySlugs": [
      "mechanics"
    ],
    "excerpt": "طقم مفاتيح استندر من منتجات Amjad Fathi Store.",
    "description": "طقم مفاتيح استندر من منتجات Amjad Fathi Store.",
    "images": [
      "/products/reference-optimized/5ea029d4-68b1-4ce7-ac64-df17311b6903.webp"
    ],
    "specifications": [],
    "inStock": true,
    "featured": false
  },
  {
    "id": "reference-514e75fc-f6c6-4f98-9004-3d911e69c282",
    "slug": "reference-514e75fc",
    "name": "جونتي مبطن",
    "categorySlug": "mechanics",
    "categorySlugs": [
      "mechanics",
      "carpentry",
      "plumbing"
    ],
    "excerpt": "جونتي مبطن من منتجات Amjad Fathi Store.",
    "description": "جونتي مبطن من منتجات Amjad Fathi Store.",
    "images": [
      "/products/reference-optimized/514e75fc-f6c6-4f98-9004-3d911e69c282.webp"
    ],
    "specifications": [],
    "inStock": true,
    "featured": false
  },
  {
    "id": "reference-eefac02e-f538-4c0b-aa31-f416f3a65f2a",
    "slug": "reference-eefac02e",
    "name": "كاوية لحام الكترونيات 60w",
    "categorySlug": "power-tools",
    "categorySlugs": [
      "power-tools"
    ],
    "excerpt": "كاوية لحام الكترونيات 60w من منتجات Amjad Fathi Store.",
    "description": "كاوية لحام الكترونيات 60w من منتجات Amjad Fathi Store.",
    "images": [
      "/products/reference-optimized/eefac02e-f538-4c0b-aa31-f416f3a65f2a.webp"
    ],
    "specifications": [],
    "inStock": true,
    "featured": false
  },
  {
    "id": "reference-2cb04f2f-4bb7-4b0a-bb22-01fbdbd124f1",
    "slug": "reference-2cb04f2f",
    "name": "ازميل 1/2 بوصة",
    "categorySlug": "carpentry",
    "categorySlugs": [
      "carpentry"
    ],
    "excerpt": "ازميل 1/2 بوصة من منتجات Amjad Fathi Store.",
    "description": "ازميل 1/2 بوصة من منتجات Amjad Fathi Store.",
    "images": [
      "/products/reference-optimized/2cb04f2f-4bb7-4b0a-bb22-01fbdbd124f1.webp"
    ],
    "specifications": [],
    "inStock": true,
    "featured": false
  },
  {
    "id": "reference-163224c0-149e-44a9-a691-68373eeaa391",
    "slug": "reference-163224c0",
    "name": "ازميل 3/4 بوصة",
    "categorySlug": "carpentry",
    "categorySlugs": [
      "carpentry"
    ],
    "excerpt": "ازميل 3/4 بوصة من منتجات Amjad Fathi Store.",
    "description": "ازميل 3/4 بوصة من منتجات Amjad Fathi Store.",
    "images": [
      "/products/reference-optimized/163224c0-149e-44a9-a691-68373eeaa391.webp"
    ],
    "specifications": [],
    "inStock": true,
    "featured": false
  },
  {
    "id": "reference-9af03a45-7fa9-4094-a02b-f1a6fb458170",
    "slug": "reference-9af03a45",
    "name": "ازميل 1 بوصة",
    "categorySlug": "carpentry",
    "categorySlugs": [
      "carpentry"
    ],
    "excerpt": "ازميل 1 بوصة من منتجات Amjad Fathi Store.",
    "description": "ازميل 1 بوصة من منتجات Amjad Fathi Store.",
    "images": [
      "/products/reference-optimized/9af03a45-7fa9-4094-a02b-f1a6fb458170.webp"
    ],
    "specifications": [],
    "inStock": true,
    "featured": false
  },
  {
    "id": "reference-e529105b-9bed-413d-b6d7-b947196a5b70",
    "slug": "reference-e529105b",
    "name": "هوفر 800w",
    "categorySlug": "power-tools",
    "categorySlugs": [
      "power-tools",
      "general-equipment"
    ],
    "excerpt": "هوفر 800w من منتجات Amjad Fathi Store.",
    "description": "هوفر 800w من منتجات Amjad Fathi Store.",
    "images": [
      "/products/reference-optimized/e529105b-9bed-413d-b6d7-b947196a5b70.webp"
    ],
    "specifications": [],
    "inStock": true,
    "featured": false
  },
  {
    "id": "reference-f78002bb-ef6f-4f8c-b717-d99839b16df7",
    "slug": "reference-f78002bb",
    "name": "هوفر شحن 2.8",
    "categorySlug": "power-tools",
    "categorySlugs": [
      "power-tools",
      "general-equipment"
    ],
    "excerpt": "هوفر شحن 2.8 من منتجات Amjad Fathi Store.",
    "description": "هوفر شحن 2.8 من منتجات Amjad Fathi Store.",
    "images": [
      "/products/reference-optimized/f78002bb-ef6f-4f8c-b717-d99839b16df7.webp"
    ],
    "specifications": [],
    "inStock": true,
    "featured": false
  },
  {
    "id": "reference-ef8ca618-0f7c-4b5c-9a0d-5bb5899071aa",
    "slug": "reference-ef8ca618",
    "name": "هوفر شحن 2.7",
    "categorySlug": "power-tools",
    "categorySlugs": [
      "power-tools",
      "general-equipment"
    ],
    "excerpt": "هوفر شحن 2.7 من منتجات Amjad Fathi Store.",
    "description": "هوفر شحن 2.7 من منتجات Amjad Fathi Store.",
    "images": [
      "/products/reference-optimized/ef8ca618-0f7c-4b5c-9a0d-5bb5899071aa.webp"
    ],
    "specifications": [],
    "inStock": true,
    "featured": false
  },
  {
    "id": "reference-6cd0024d-0d1b-4f8b-9e1d-8e8dcd10a29b",
    "slug": "reference-6cd0024d",
    "name": "قشارة أسلاك 1*4",
    "categorySlug": "power-tools",
    "categorySlugs": [
      "power-tools"
    ],
    "excerpt": "قشارة أسلاك 1*4 من منتجات Amjad Fathi Store.",
    "description": "قشارة أسلاك 1*4 من منتجات Amjad Fathi Store.",
    "images": [
      "/products/reference-optimized/6cd0024d-0d1b-4f8b-9e1d-8e8dcd10a29b.webp"
    ],
    "specifications": [],
    "inStock": true,
    "featured": false
  },
  {
    "id": "reference-b18ad8b5-171e-491a-88d1-ae4758c1654e",
    "slug": "reference-b18ad8b5",
    "name": "كلامبيتر 1200 AC/DC",
    "categorySlug": "power-tools",
    "categorySlugs": [
      "power-tools"
    ],
    "excerpt": "كلامبيتر 1200 AC/DC من منتجات Amjad Fathi Store.",
    "description": "كلامبيتر 1200 AC/DC من منتجات Amjad Fathi Store.",
    "images": [
      "/products/reference-optimized/b18ad8b5-171e-491a-88d1-ae4758c1654e.webp"
    ],
    "specifications": [],
    "inStock": true,
    "featured": false
  },
  {
    "id": "reference-38ccf108-47f7-4499-87f6-43e164d3ebc7",
    "slug": "reference-38ccf108",
    "name": "طقم زردية",
    "categorySlug": "mechanics",
    "categorySlugs": [
      "mechanics"
    ],
    "excerpt": "طقم زردية من منتجات Amjad Fathi Store.",
    "description": "طقم زردية من منتجات Amjad Fathi Store.",
    "images": [
      "/products/reference-optimized/38ccf108-47f7-4499-87f6-43e164d3ebc7.webp"
    ],
    "specifications": [],
    "inStock": true,
    "featured": false
  },
  {
    "id": "reference-beadd373-129b-4515-bbc5-be9ea0b95623",
    "slug": "reference-beadd373",
    "name": "طقم زردية تيل",
    "categorySlug": "mechanics",
    "categorySlugs": [
      "mechanics"
    ],
    "excerpt": "طقم زردية تيل من منتجات Amjad Fathi Store.",
    "description": "طقم زردية تيل من منتجات Amjad Fathi Store.",
    "images": [
      "/products/reference-optimized/beadd373-129b-4515-bbc5-be9ea0b95623.webp"
    ],
    "specifications": [],
    "inStock": true,
    "featured": false
  },
  {
    "id": "reference-0b4d0318-3601-4228-87a5-08b9e543fa6f",
    "slug": "reference-0b4d0318",
    "name": "طقم مفتاح طقطاق",
    "categorySlug": "mechanics",
    "categorySlugs": [
      "mechanics"
    ],
    "excerpt": "طقم مفتاح طقطاق من منتجات Amjad Fathi Store.",
    "description": "طقم مفتاح طقطاق من منتجات Amjad Fathi Store.",
    "images": [
      "/products/reference-optimized/0b4d0318-3601-4228-87a5-08b9e543fa6f.webp"
    ],
    "specifications": [],
    "inStock": true,
    "featured": false
  },
  {
    "id": "reference-58c4e0a9-c00b-4774-84da-789b014b4531",
    "slug": "reference-58c4e0a9",
    "name": "طقم مفاتيح بلدي مشترك",
    "categorySlug": "mechanics",
    "categorySlugs": [
      "mechanics"
    ],
    "excerpt": "طقم مفاتيح بلدي مشترك من منتجات Amjad Fathi Store.",
    "description": "طقم مفاتيح بلدي مشترك من منتجات Amjad Fathi Store.",
    "images": [
      "/products/reference-optimized/58c4e0a9-c00b-4774-84da-789b014b4531.webp"
    ],
    "specifications": [],
    "inStock": true,
    "featured": false
  },
  {
    "id": "reference-32bfdf1f-8eeb-4827-9385-4a232d9175c4",
    "slug": "reference-32bfdf1f",
    "name": "درل رباط 230 نيوتن",
    "categorySlug": "mechanics",
    "categorySlugs": [
      "mechanics"
    ],
    "excerpt": "درل رباط 230 نيوتن من منتجات Amjad Fathi Store.",
    "description": "درل رباط 230 نيوتن من منتجات Amjad Fathi Store.",
    "images": [
      "/products/reference-optimized/32bfdf1f-8eeb-4827-9385-4a232d9175c4.webp"
    ],
    "specifications": [],
    "inStock": true,
    "featured": false
  },
  {
    "id": "reference-d713e578-0c01-4d81-b8a7-775591a4f007",
    "slug": "reference-d713e578",
    "name": "درل رباط 850 نيوتن",
    "categorySlug": "mechanics",
    "categorySlugs": [
      "mechanics"
    ],
    "excerpt": "درل رباط 850 نيوتن من منتجات Amjad Fathi Store.",
    "description": "درل رباط 850 نيوتن من منتجات Amjad Fathi Store.",
    "images": [
      "/products/reference-optimized/d713e578-0c01-4d81-b8a7-775591a4f007.webp"
    ],
    "specifications": [],
    "inStock": true,
    "featured": false
  },
  {
    "id": "reference-4d03e849-811d-4c70-a344-0930a5bc021d",
    "slug": "reference-4d03e849",
    "name": "درل رباط 1350 نيوتن",
    "categorySlug": "mechanics",
    "categorySlugs": [
      "mechanics"
    ],
    "excerpt": "درل رباط 1350 نيوتن من منتجات Amjad Fathi Store.",
    "description": "درل رباط 1350 نيوتن من منتجات Amjad Fathi Store.",
    "images": [
      "/products/reference-optimized/4d03e849-811d-4c70-a344-0930a5bc021d.webp"
    ],
    "specifications": [],
    "inStock": true,
    "featured": false
  },
  {
    "id": "reference-e31e0d3d-2112-48e9-baf2-b56fbf4578ab",
    "slug": "reference-e31e0d3d",
    "name": "شنطة حبوب درل 14 قطعة",
    "categorySlug": "mechanics",
    "categorySlugs": [
      "mechanics"
    ],
    "excerpt": "شنطة حبوب درل 14 قطعة من منتجات Amjad Fathi Store.",
    "description": "شنطة حبوب درل 14 قطعة من منتجات Amjad Fathi Store.",
    "images": [
      "/products/reference-optimized/e31e0d3d-2112-48e9-baf2-b56fbf4578ab.webp"
    ],
    "specifications": [],
    "inStock": true,
    "featured": false
  },
  {
    "id": "reference-ccc68c11-f5ff-4de1-a669-39534f86c5f5",
    "slug": "reference-ccc68c11",
    "name": "شنطة عدة 24 قطعة",
    "categorySlug": "mechanics",
    "categorySlugs": [
      "mechanics"
    ],
    "excerpt": "شنطة عدة 24 قطعة من منتجات Amjad Fathi Store.",
    "description": "شنطة عدة 24 قطعة من منتجات Amjad Fathi Store.",
    "images": [
      "/products/reference-optimized/ccc68c11-f5ff-4de1-a669-39534f86c5f5.webp"
    ],
    "specifications": [],
    "inStock": true,
    "featured": false
  },
  {
    "id": "reference-6f1645ad-e258-43a6-b9e5-4138b0841a66",
    "slug": "reference-6f1645ad",
    "name": "شنطة عدة 132 قطعة",
    "categorySlug": "mechanics",
    "categorySlugs": [
      "mechanics"
    ],
    "excerpt": "شنطة عدة 132 قطعة من منتجات Amjad Fathi Store.",
    "description": "شنطة عدة 132 قطعة من منتجات Amjad Fathi Store.",
    "images": [
      "/products/reference-optimized/6f1645ad-e258-43a6-b9e5-4138b0841a66.webp"
    ],
    "specifications": [],
    "inStock": true,
    "featured": false
  },
  {
    "id": "reference-7b74d950-2716-43b0-8e9f-4149e5e79f3b",
    "slug": "reference-7b74d950",
    "name": "مفتاح انجليزي 12 بوصة",
    "categorySlug": "plumbing",
    "categorySlugs": [
      "plumbing"
    ],
    "excerpt": "مفتاح انجليزي 12 بوصة من منتجات Amjad Fathi Store.",
    "description": "مفتاح انجليزي 12 بوصة من منتجات Amjad Fathi Store.",
    "images": [
      "/products/reference-optimized/7b74d950-2716-43b0-8e9f-4149e5e79f3b.webp"
    ],
    "specifications": [],
    "inStock": true,
    "featured": false
  },
  {
    "id": "reference-f741438b-531c-4355-9c70-74e251678477",
    "slug": "reference-f741438b",
    "name": "مفتاح انجليزي 10 بوصة",
    "categorySlug": "plumbing",
    "categorySlugs": [
      "plumbing"
    ],
    "excerpt": "مفتاح انجليزي 10 بوصة من منتجات Amjad Fathi Store.",
    "description": "مفتاح انجليزي 10 بوصة من منتجات Amjad Fathi Store.",
    "images": [
      "/products/reference-optimized/f741438b-531c-4355-9c70-74e251678477.webp"
    ],
    "specifications": [],
    "inStock": true,
    "featured": false
  },
  {
    "id": "reference-6a186ab7-1600-433a-9576-e882b95bdf63",
    "slug": "reference-6a186ab7",
    "name": "مفتاح انجليزي 8 بوصة",
    "categorySlug": "plumbing",
    "categorySlugs": [
      "plumbing"
    ],
    "excerpt": "مفتاح انجليزي 8 بوصة من منتجات Amjad Fathi Store.",
    "description": "مفتاح انجليزي 8 بوصة من منتجات Amjad Fathi Store.",
    "images": [
      "/products/reference-optimized/6a186ab7-1600-433a-9576-e882b95bdf63.webp"
    ],
    "specifications": [],
    "inStock": true,
    "featured": false
  },
  {
    "id": "reference-3b5b376b-bdd6-445f-8535-d37510344fc0",
    "slug": "reference-3b5b376b",
    "name": "ماكينة لحام BBR",
    "categorySlug": "plumbing",
    "categorySlugs": [
      "plumbing"
    ],
    "excerpt": "ماكينة لحام BBR من منتجات Amjad Fathi Store.",
    "description": "ماكينة لحام BBR من منتجات Amjad Fathi Store.",
    "images": [
      "/products/reference-optimized/3b5b376b-bdd6-445f-8535-d37510344fc0.webp"
    ],
    "specifications": [],
    "inStock": true,
    "featured": false
  },
  {
    "id": "reference-1a107cc6-42bf-43c5-af35-181c411a570f",
    "slug": "reference-1a107cc6",
    "name": "ماكينة لحام BBR شحن",
    "categorySlug": "plumbing",
    "categorySlugs": [
      "plumbing"
    ],
    "excerpt": "ماكينة لحام BBR شحن من منتجات Amjad Fathi Store.",
    "description": "ماكينة لحام BBR شحن من منتجات Amjad Fathi Store.",
    "images": [
      "/products/reference-optimized/1a107cc6-42bf-43c5-af35-181c411a570f.webp"
    ],
    "specifications": [],
    "inStock": true,
    "featured": false
  },
  {
    "id": "reference-cddacbbb-41f2-4462-95bd-05c2cf463fbe",
    "slug": "reference-cddacbbb",
    "name": "حجر نار 1 بطارية شحن 900w",
    "categorySlug": "metalwork",
    "categorySlugs": [
      "metalwork"
    ],
    "excerpt": "حجر نار 1 بطارية شحن 900w من منتجات Amjad Fathi Store.",
    "description": "حجر نار 1 بطارية شحن 900w من منتجات Amjad Fathi Store.",
    "images": [
      "/products/reference-optimized/cddacbbb-41f2-4462-95bd-05c2cf463fbe.webp"
    ],
    "specifications": [],
    "inStock": true,
    "featured": false
  },
  {
    "id": "reference-616d8116-2008-4baf-a4c1-2912130a7bfa",
    "slug": "reference-616d8116",
    "name": "حجر مسن 350w",
    "categorySlug": "metalwork",
    "categorySlugs": [
      "metalwork"
    ],
    "excerpt": "حجر مسن 350w من منتجات Amjad Fathi Store.",
    "description": "حجر مسن 350w من منتجات Amjad Fathi Store.",
    "images": [
      "/products/reference-optimized/616d8116-2008-4baf-a4c1-2912130a7bfa.webp"
    ],
    "specifications": [],
    "inStock": true,
    "featured": false
  },
  {
    "id": "reference-1c74fe67-f44f-4736-a820-e4ae094a179d",
    "slug": "reference-1c74fe67",
    "name": "حجر نار 9 بوصة 2200w",
    "categorySlug": "metalwork",
    "categorySlugs": [
      "metalwork"
    ],
    "excerpt": "حجر نار 9 بوصة 2200w من منتجات Amjad Fathi Store.",
    "description": "حجر نار 9 بوصة 2200w من منتجات Amjad Fathi Store.",
    "images": [
      "/products/reference-optimized/1c74fe67-f44f-4736-a820-e4ae094a179d.webp"
    ],
    "specifications": [],
    "inStock": true,
    "featured": false
  },
  {
    "id": "reference-ba588e9f-14f3-4910-9aff-f2ab97cf7b2b",
    "slug": "reference-ba588e9f",
    "name": "حجر نار 4.5 بوصة 710w",
    "categorySlug": "metalwork",
    "categorySlugs": [
      "metalwork"
    ],
    "excerpt": "حجر نار 4.5 بوصة 710w من منتجات Amjad Fathi Store.",
    "description": "حجر نار 4.5 بوصة 710w من منتجات Amjad Fathi Store.",
    "images": [
      "/products/reference-optimized/ba588e9f-14f3-4910-9aff-f2ab97cf7b2b.webp"
    ],
    "specifications": [],
    "inStock": true,
    "featured": false
  },
  {
    "id": "reference-2d4192d6-f0d0-46c5-bbad-fec938864f06",
    "slug": "reference-2d4192d6",
    "name": "دربكين 13 ملم 900w",
    "categorySlug": "metalwork",
    "categorySlugs": [
      "metalwork"
    ],
    "excerpt": "دربكين 13 ملم 900w من منتجات Amjad Fathi Store.",
    "description": "دربكين 13 ملم 900w من منتجات Amjad Fathi Store.",
    "images": [
      "/products/reference-optimized/2d4192d6-f0d0-46c5-bbad-fec938864f06.webp"
    ],
    "specifications": [],
    "inStock": true,
    "featured": false
  },
  {
    "id": "reference-e0528500-1a5d-4f6c-8c9d-395d40d6a366",
    "slug": "reference-e0528500",
    "name": "دربكين شحن 1 بطارية 55 نيوتن",
    "categorySlug": "metalwork",
    "categorySlugs": [
      "metalwork",
      "power-tools"
    ],
    "excerpt": "دربكين شحن 1 بطارية 55 نيوتن من منتجات Amjad Fathi Store.",
    "description": "دربكين شحن 1 بطارية 55 نيوتن من منتجات Amjad Fathi Store.",
    "images": [
      "/products/reference-optimized/e0528500-1a5d-4f6c-8c9d-395d40d6a366.webp"
    ],
    "specifications": [],
    "inStock": true,
    "featured": false
  },
  {
    "id": "reference-8a89d919-f41b-42bc-bfe0-6a84a94fae31",
    "slug": "reference-8a89d919",
    "name": "طارة قطع 4.5 بوصة",
    "categorySlug": "metalwork",
    "categorySlugs": [
      "metalwork"
    ],
    "excerpt": "طارة قطع 4.5 بوصة من منتجات Amjad Fathi Store.",
    "description": "طارة قطع 4.5 بوصة من منتجات Amjad Fathi Store.",
    "images": [
      "/products/reference-optimized/8a89d919-f41b-42bc-bfe0-6a84a94fae31.webp"
    ],
    "specifications": [],
    "inStock": true,
    "featured": false
  },
  {
    "id": "reference-2253ead3-0b08-452e-b886-e7143c9c7e3f",
    "slug": "reference-2253ead3",
    "name": "طارة قطع 9 بوصة",
    "categorySlug": "metalwork",
    "categorySlugs": [
      "metalwork"
    ],
    "excerpt": "طارة قطع 9 بوصة من منتجات Amjad Fathi Store.",
    "description": "طارة قطع 9 بوصة من منتجات Amjad Fathi Store.",
    "images": [
      "/products/reference-optimized/2253ead3-0b08-452e-b886-e7143c9c7e3f.webp"
    ],
    "specifications": [],
    "inStock": true,
    "featured": false
  },
  {
    "id": "reference-07df9c56-d44c-436a-a62f-346f6095bcfe",
    "slug": "reference-07df9c56",
    "name": "طارة قطع 16 بوصة",
    "categorySlug": "metalwork",
    "categorySlugs": [
      "metalwork"
    ],
    "excerpt": "طارة قطع 16 بوصة من منتجات Amjad Fathi Store.",
    "description": "طارة قطع 16 بوصة من منتجات Amjad Fathi Store.",
    "images": [
      "/products/reference-optimized/07df9c56-d44c-436a-a62f-346f6095bcfe.webp"
    ],
    "specifications": [],
    "inStock": true,
    "featured": false
  },
  {
    "id": "reference-9f42561e-1d82-4e3a-ae7b-deda7c86738f",
    "slug": "reference-9f42561e",
    "name": "دربكين شحن 2 بطارية 96 نيوتن",
    "categorySlug": "metalwork",
    "categorySlugs": [
      "metalwork",
      "power-tools"
    ],
    "excerpt": "دربكين شحن 2 بطارية 96 نيوتن من منتجات Amjad Fathi Store.",
    "description": "دربكين شحن 2 بطارية 96 نيوتن من منتجات Amjad Fathi Store.",
    "images": [
      "/products/reference-optimized/9f42561e-1d82-4e3a-ae7b-deda7c86738f.webp"
    ],
    "specifications": [],
    "inStock": true,
    "featured": false
  },
  {
    "id": "reference-572f6306-105e-4527-b686-562b1ff0cf6b",
    "slug": "reference-572f6306",
    "name": "دربكين شحن 2 بطارية 66 نيوتن",
    "categorySlug": "metalwork",
    "categorySlugs": [
      "metalwork",
      "power-tools"
    ],
    "excerpt": "دربكين شحن 2 بطارية 66 نيوتن من منتجات Amjad Fathi Store.",
    "description": "دربكين شحن 2 بطارية 66 نيوتن من منتجات Amjad Fathi Store.",
    "images": [
      "/products/reference-optimized/572f6306-105e-4527-b686-562b1ff0cf6b.webp"
    ],
    "specifications": [],
    "inStock": true,
    "featured": false
  },
  {
    "id": "reference-20724bd8-89a6-4fa8-ae84-f5896835e48b",
    "slug": "reference-20724bd8",
    "name": "دربكين شحن 2 بطارية 55 نيوتن",
    "categorySlug": "metalwork",
    "categorySlugs": [
      "metalwork",
      "power-tools"
    ],
    "excerpt": "دربكين شحن 2 بطارية 55 نيوتن من منتجات Amjad Fathi Store.",
    "description": "دربكين شحن 2 بطارية 55 نيوتن من منتجات Amjad Fathi Store.",
    "images": [
      "/products/reference-optimized/20724bd8-89a6-4fa8-ae84-f5896835e48b.webp"
    ],
    "specifications": [],
    "inStock": true,
    "featured": false
  },
  {
    "id": "reference-be732476-2d23-4916-ae64-d86050e9b3aa",
    "slug": "reference-be732476",
    "name": "دربكين 13 ملم 810w ",
    "categorySlug": "metalwork",
    "categorySlugs": [
      "metalwork"
    ],
    "excerpt": "دربكين 13 ملم 810w  من منتجات Amjad Fathi Store.",
    "description": "دربكين 13 ملم 810w  من منتجات Amjad Fathi Store.",
    "images": [
      "/products/reference-optimized/be732476-2d23-4916-ae64-d86050e9b3aa.webp"
    ],
    "specifications": [],
    "inStock": true,
    "featured": false
  },
  {
    "id": "reference-262cd1cd-2fa4-4b90-9bd4-3f472190fdd7",
    "slug": "reference-262cd1cd",
    "name": "حجر نار شحن 2 بطارية 1000w",
    "categorySlug": "metalwork",
    "categorySlugs": [
      "metalwork"
    ],
    "excerpt": "حجر نار شحن 2 بطارية 1000w من منتجات Amjad Fathi Store.",
    "description": "حجر نار شحن 2 بطارية 1000w من منتجات Amjad Fathi Store.",
    "images": [
      "/products/reference-optimized/262cd1cd-2fa4-4b90-9bd4-3f472190fdd7.webp"
    ],
    "specifications": [],
    "inStock": true,
    "featured": false
  },
  {
    "id": "reference-94195c06-e6a3-4595-86f1-99fde8dc77b4",
    "slug": "reference-94195c06",
    "name": "حجر نار 4.5 بوصة 750w",
    "categorySlug": "metalwork",
    "categorySlugs": [
      "metalwork"
    ],
    "excerpt": "حجر نار 4.5 بوصة 750w من منتجات Amjad Fathi Store.",
    "description": "حجر نار 4.5 بوصة 750w من منتجات Amjad Fathi Store.",
    "images": [
      "/products/reference-optimized/94195c06-e6a3-4595-86f1-99fde8dc77b4.webp"
    ],
    "specifications": [],
    "inStock": true,
    "featured": false
  },
  {
    "id": "reference-fe43503b-b7e7-4b9a-a48f-d5b0b4c74c3a",
    "slug": "reference-fe43503b",
    "name": "حجر نار 9 بوصة 2400w",
    "categorySlug": "metalwork",
    "categorySlugs": [
      "metalwork"
    ],
    "excerpt": "حجر نار 9 بوصة 2400w من منتجات Amjad Fathi Store.",
    "description": "حجر نار 9 بوصة 2400w من منتجات Amjad Fathi Store.",
    "images": [
      "/products/reference-optimized/fe43503b-b7e7-4b9a-a48f-d5b0b4c74c3a.webp"
    ],
    "specifications": [],
    "inStock": true,
    "featured": false
  },
  {
    "id": "reference-f332c8b5-63d3-4e47-a763-2b2c66c3adc7",
    "slug": "reference-f332c8b5",
    "name": "ماكينة لحام الكترونية 250 امبير",
    "categorySlug": "metalwork",
    "categorySlugs": [
      "metalwork"
    ],
    "excerpt": "ماكينة لحام الكترونية 250 امبير من منتجات Amjad Fathi Store.",
    "description": "ماكينة لحام الكترونية 250 امبير من منتجات Amjad Fathi Store.",
    "images": [
      "/products/reference-optimized/f332c8b5-63d3-4e47-a763-2b2c66c3adc7.webp"
    ],
    "specifications": [],
    "inStock": true,
    "featured": false
  },
  {
    "id": "reference-9cc2056c-b89c-4b6f-8e07-3547e1dc2f90",
    "slug": "reference-9cc2056c",
    "name": "قاطع خشب شحن 5.5 بوصة",
    "categorySlug": "carpentry",
    "categorySlugs": [
      "carpentry"
    ],
    "excerpt": "قاطع خشب شحن 5.5 بوصة من منتجات Amjad Fathi Store.",
    "description": "قاطع خشب شحن 5.5 بوصة من منتجات Amjad Fathi Store.",
    "images": [
      "/products/reference-optimized/9cc2056c-b89c-4b6f-8e07-3547e1dc2f90.webp"
    ],
    "specifications": [],
    "inStock": true,
    "featured": false
  },
  {
    "id": "reference-91d7c140-fc54-4ec9-b6f9-204cdb2e04a2",
    "slug": "reference-91d7c140",
    "name": "منشار خشب 800 واط",
    "categorySlug": "carpentry",
    "categorySlugs": [
      "carpentry"
    ],
    "excerpt": "منشار خشب 800 واط من منتجات Amjad Fathi Store.",
    "description": "منشار خشب 800 واط من منتجات Amjad Fathi Store.",
    "images": [
      "/products/reference-optimized/91d7c140-fc54-4ec9-b6f9-204cdb2e04a2.webp"
    ],
    "specifications": [],
    "inStock": true,
    "featured": false
  },
  {
    "id": "reference-7f9efae3-39fa-4155-b716-d7321867e7f5",
    "slug": "reference-7f9efae3",
    "name": "ماكينة لحام AC/DC غاز 200 امبير",
    "categorySlug": "metalwork",
    "categorySlugs": [
      "metalwork"
    ],
    "excerpt": "ماكينة لحام AC/DC غاز 200 امبير من منتجات Amjad Fathi Store.",
    "description": "ماكينة لحام AC/DC غاز 200 امبير من منتجات Amjad Fathi Store.",
    "images": [
      "/products/reference-optimized/7f9efae3-39fa-4155-b716-d7321867e7f5.webp"
    ],
    "specifications": [],
    "inStock": true,
    "featured": false
  },
  {
    "id": "reference-1425f35f-cde2-441f-a345-b7f045ef6ca5",
    "slug": "reference-1425f35f",
    "name": "قاطع 14 بوصة كوبلن",
    "categorySlug": "metalwork",
    "categorySlugs": [
      "metalwork"
    ],
    "excerpt": "قاطع 14 بوصة كوبلن من منتجات Amjad Fathi Store.",
    "description": "قاطع 14 بوصة كوبلن من منتجات Amjad Fathi Store.",
    "images": [
      "/products/reference-optimized/1425f35f-cde2-441f-a345-b7f045ef6ca5.webp"
    ],
    "specifications": [],
    "inStock": true,
    "featured": false
  }
];
