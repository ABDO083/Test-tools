import Link from 'next/link'
import { buttonVariants } from '@/components/ui/button'

export default function NotFound() {
  return (
    <div className="mx-auto flex min-h-[60vh] w-full max-w-2xl flex-col items-center justify-center px-4 py-16 text-center">
      <span className="font-display text-6xl font-bold text-accent">404</span>
      <h1 className="mt-4 text-2xl font-bold">الصفحة غير موجودة</h1>
      <p className="mt-2 text-muted-foreground">
        عذراً، لم نتمكّن من العثور على الصفحة التي تبحث عنها.
      </p>
      <div className="mt-8 flex flex-wrap justify-center gap-3">
        <Link href="/" className={buttonVariants({ size: 'lg' })}>العودة للرئيسية</Link>
        <Link href="/products" className={buttonVariants({ size: 'lg', variant: 'outline' })}>تصفّح المنتجات</Link>
      </div>
    </div>
  )
}
