import { Suspense } from 'react'
import { HeroSection } from '@/components/hero-section'
import { ProductCatalog } from '@/components/product-catalog'
import { ProductGrid } from '@/components/product-grid'
import { getCategories, getProducts } from '@/lib/api'

export default async function HomePage() {
  const [categories, products] = await Promise.all([getCategories(), getProducts()])

  return (
    <>
      <HeroSection />
      <section className="reference-catalog w-full px-4 py-6 text-slate-900 sm:px-6 sm:py-8 lg:px-8">
        <div className="mx-auto w-full max-w-7xl">
          <Suspense fallback={<ProductGrid products={[]} loading />}>
            <ProductCatalog categories={categories} initialProducts={products} showSearch={false} showSort={false} />
          </Suspense>
        </div>
      </section>
    </>
  )
}
