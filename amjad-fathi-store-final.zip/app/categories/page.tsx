import type { Metadata } from 'next'
import { PageBanner } from '@/components/page-banner'
import { CategoryCard } from '@/components/category-card'
import { getCategories, getProductCountByCategory } from '@/lib/api'

export const metadata: Metadata = {
  title: 'التصنيفات | Amjad Fathi Store',
  description: 'تصفح تصنيفات أدوات ومعدات Amjad Fathi Store.',
}

export default async function CategoriesPage() {
  const [categories, counts] = await Promise.all([
    getCategories(),
    getProductCountByCategory(),
  ])

  return (
    <>
      <PageBanner title="التصنيفات" description="اختر القسم للوصول إلى منتجاته مباشرة." />
      <section className="reference-catalog w-full px-4 py-8 sm:px-6 lg:px-8">
        <div className="mx-auto w-full max-w-7xl">
          <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-4">
            {categories.map((category) => (
              <CategoryCard key={category.slug} category={category} count={counts[category.slug]} />
            ))}
          </div>
        </div>
      </section>
    </>
  )
}
