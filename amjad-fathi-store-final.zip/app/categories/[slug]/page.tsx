import { Suspense } from 'react'
import Link from 'next/link'
import { notFound } from 'next/navigation'
import type { Metadata } from 'next'
import { PageBanner } from '@/components/page-banner'
import { ProductCatalog } from '@/components/product-catalog'
import { ProductGrid } from '@/components/product-grid'
import { getCategories, getCategory, getProducts } from '@/lib/api'

export async function generateStaticParams() {
  const categories = await getCategories()
  return categories.map((c) => ({ slug: c.slug }))
}

export async function generateMetadata({
  params,
}: {
  params: Promise<{ slug: string }>
}): Promise<Metadata> {
  const { slug } = await params
  const category = await getCategory(slug)
  if (!category) return { title: 'التصنيف غير موجود | Amjad Fathi Store' }
  return {
    title: `${category.name} | Amjad Fathi Store`,
    description: category.description,
  }
}

export default async function CategoryPage({
  params,
}: {
  params: Promise<{ slug: string }>
}) {
  const { slug } = await params
  const [category, categories, products] = await Promise.all([getCategory(slug), getCategories(), getProducts()])

  if (!category) notFound()

  return (
    <>
      <PageBanner title={category.name} description={category.description} eyebrow="Amjad Fathi Store" />
      <section className="reference-catalog w-full px-4 py-8 sm:px-6 lg:px-8">
        <div className="mx-auto w-full max-w-7xl">
          <Suspense fallback={<ProductGrid products={[]} loading />}>
            <ProductCatalog
              categories={categories}
              initialProducts={products}
              initialCategory={category.slug}
              showCategoryFilter={false}
            />
          </Suspense>
          <Link href="/categories" className="mt-8 inline-flex text-sm font-bold text-primary hover:underline">
            العودة إلى التصنيفات
          </Link>
        </div>
      </section>
    </>
  )
}
