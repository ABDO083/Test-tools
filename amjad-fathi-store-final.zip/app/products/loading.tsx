import { Skeleton } from '@/components/ui/skeleton'
import { ProductGrid } from '@/components/product-grid'

export default function Loading() {
  return (
    <div className="mx-auto w-full max-w-7xl px-4 py-10 sm:px-6 lg:px-8">
      <div className="mb-8 space-y-3">
        <Skeleton className="h-9 w-56" />
        <Skeleton className="h-4 w-80 max-w-full" />
      </div>
      <Skeleton className="mb-5 h-14 w-full rounded-full" />
      <ProductGrid products={[]} loading />
    </div>
  )
}
