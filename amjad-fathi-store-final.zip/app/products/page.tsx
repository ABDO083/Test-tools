import { Suspense } from 'react'
import type { Metadata } from 'next'
import { PageBanner } from '@/components/page-banner'
import { ProductCatalog } from '@/components/product-catalog'
import { ProductGrid } from '@/components/product-grid'
import { getCategories, getProducts } from '@/lib/api'

export const metadata: Metadata = {
  title: 'المنتجات | Amjad Fathi Store',
  description: 'تصفح منتجات وأدوات Amjad Fathi Store.',
}

export default async function ProductsPage({
  searchParams,
}: {
  searchParams: Promise<{ search?: string; category?: string }>
}) {
  const [categories, products, params] = await Promise.all([getCategories(), getProducts(), searchParams])

  return (
    <>
      <PageBanner title="المنتجات" description="اختَر المنتج المناسب لمهمتك." />
      <section className="reference-catalog w-full px-4 py-6 text-slate-900 sm:px-6 sm:py-8 lg:px-8">
        <div className="mx-auto w-full max-w-7xl">
          <Suspense fallback={<ProductGrid products={[]} loading />}>
            <ProductCatalog
              categories={categories}
              initialProducts={products}
              initialCategory={params.category ?? 'all'}
              initialSearch={params.search ?? ''}
            />
          </Suspense>
        </div>
      </section>
    </>
  )
}
