import { notFound } from 'next/navigation'
import type { Metadata } from 'next'
import { PageBanner } from '@/components/page-banner'
import { ProductDetails } from '@/components/product-details'
import { RelatedProducts } from '@/components/related-products'
import { getProductBySlug, getRelatedProducts, getProducts } from '@/lib/api'

export async function generateStaticParams() {
  const products = await getProducts()
  return products.map((p) => ({ slug: p.slug }))
}

export async function generateMetadata({
  params,
}: {
  params: Promise<{ slug: string }>
}): Promise<Metadata> {
  const { slug } = await params
  const product = await getProductBySlug(slug)
  if (!product) return { title: 'المنتج غير موجود | Amjad Fathi Store' }
  return {
    title: `${product.name} | Amjad Fathi Store`,
    description: product.excerpt,
    openGraph: { images: product.images },
  }
}

export default async function ProductPage({
  params,
}: {
  params: Promise<{ slug: string }>
}) {
  const { slug } = await params
  const product = await getProductBySlug(slug)

  if (!product) notFound()

  const related = await getRelatedProducts(product, 4)

  return (
    <>
      <PageBanner title="تفاصيل المنتج" description={product.name} eyebrow="Amjad Fathi Store" />
      <section className="reference-catalog w-full px-4 py-6 sm:px-6 sm:py-8 lg:px-8">
        <div className="mx-auto w-full max-w-7xl">
          <ProductDetails product={product} />
          <RelatedProducts products={related} />
        </div>
      </section>
    </>
  )
}
